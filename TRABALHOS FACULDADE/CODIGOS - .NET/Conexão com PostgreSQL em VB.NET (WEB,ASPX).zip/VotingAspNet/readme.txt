Deployment instructions:

1. unzip the VotingAspNet.zip file
2. Create a directory c:\Inetpub\wwwroot\VotingAspNet\ on your webserver
3. Copy all files - including bin and results directories - into this directory
4. Set change or writing rights for the file /Results/Results.xml to save voting results for the IUSR_* account
5. Start internet explorer an type for example http://localhost/VotingAspNet/VotingForm.aspx into the URL
6. Voting example starts and you can vote. To repeat voting please delete your cookie in the cookie directory of the account logged in

The voting is ready to customize for your voting questions.
