<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<?php
/*
 Copyright (c) 2007 Aparecido Silva
 Virtual Mail 2.0
 E-mail: djsync@uol.com.br
 MSN: djsync@uol.com.br
 Por favor n�o tire os copyright �2007
*/
/* Alterar o valor "sua_conta" do caminho abaixo Para Funciona na HostNet
a pasta home ser� criada na hora que voc� instala o ultramail na sua hospedagem
*/
include_once( '/home/lojavirtual/ultramail/ultramail.php' );

$erro=0;
if (empty($nome)){
echo "<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox1'>
    <tr>
      <td><img src='img/error.gif' width='24' height='24' /></td>
      <td>Por Favor digitar o nome corretamente.</td>
    </tr>
</table><br>"; $erro=1;}
if (empty($email)){
echo "<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox2'>
  <tr>
    <td><img src='img/error.gif' width='24' height='24' /></td>
    <td>Por Favor digitar o e-mail corretamente.</td>
  </tr>
</table><br>"; $erro=1;}
if (empty($dep)){
echo "<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox3'>
  <tr>
    <td><img src='img/error.gif' width='24' height='24' /></td>
    <td>Por Favor selecione o departamento.</td>
  </tr>
</table><br>"; $erro=1;}
if (empty($ass)){
echo "<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox4'>
  <tr>
    <td><img src='img/error.gif' width='24' height='24' /></td>
    <td>Por Favor digitar o assunto corretamente.</td>
  </tr>
</table><br>"; $erro=1;}
if (empty($men)){
echo "<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox5'>
  <tr>
    <td><img src='img/error.gif' width='24' height='24' /></td>
    <td>Por Favor digitar a mensagem corretamente.</td>
  </tr>
</table><br>"; $erro=1;}
  if($erro==0)
  {
$data = date("d/m/y"); // * Fun��o para pegar a data de envio do e-mail
$ip = $_SERVER['REMOTE_ADDR']; // * Fun��o para pegar o ip do usu�rio
$navegador = $_SERVER['HTTP_USER_AGENT']; // * Fun��o para pegar o navegador do visitante
$hora = date("H:i"); // * Fun��o para pegar a hora com a fun��o date

$djsyncmsg = "Nome do Usu�rio: $nome\n";
$djsyncmsg .= "E-mail: $email\n";
$djsyncmsg .= "Data: $data\n";
$djsyncmsg .= "Horas: $hora\n";
$djsyncmsg .= "IP: $ip\n";
$djsyncmsg .= "Assunto: $ass\n";
$djsyncmsg .= "Departamento: $dep\n";
$djsyncmsg .= "Mensagem: \n\n$men";



// * Aqui envia o e-mail para voc�

$envia = ultramail ("djsync@uol.com.br","$dep",$djsyncmsg);
if ($envia) {
echo"<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox3'>
  <tr>
    <td width='28'><div align='center'><img src='img/ok.gif' width='16' height='16' /></div></td>
    <td width='250'>Seu E-mail foi enviado com sucesso! Obrigado por entrar em contato conosco!</td>
  </tr>
</table>"; // * Mensagerm de Agradecimento.
} else {
echo "Problemas no envio, por favor tente novamente!\n";
echo "><a href='javascript:history.back(-1)'>Voltar</a>";
}
// * configura��es para enviar o e-mail para o visitante

$site = "djsync@uol.com.br"; // *e-mail que aparecer� na caixa postal do visitante
$titulo = "RE: Obrigado por Entrar em contato Conosco"; // * Titulo da mensagem enviada para o visitante
$html = "
<html>
<head>
<style type='text/css'>
<!--
.errorBox3 {
	font-family : Arial, Helvetica, sans-serif;
	font-size : 12px;
	font-weight: bolder;
	border: 1px solid #99CC99;
	height: 30px;
	width: 280px;
	background-color: #E2F9E3;
	}
-->
</style>
</head>
<body>
<table width='0' border='0' cellpadding='0' cellspacing='0' class='errorBox3'>
  <tr>
    <td width='28'><div align='center'><img src='http://www.lojavirtual.web.br.com/virtualmail/img/okstatus.gif' width='22' height='22' /></div></td>
    <td width='250'>Seu email foi recebido, logo entraremos em contato. Durante este tempo n&atilde;o envie outro";
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";



// * Aqui envia o e-mail de auto-resposta para o visitante

ultramail("$email","$titulo","$html","$headers","From: $site");

?>
<?
}
?>
<title>Enviando E-Mail</title><p><a href="javascript:history.back(-1)"> Voltar </a></p>
<p align="center" class="copyright">Powered By <a href="mailto:djsync@uol.com.br" class="textdatatime"><strong>Dj Sync</strong></a> &copy;2007 - Todos os direitos   reservados. </p>
