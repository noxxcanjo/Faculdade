<?php
/*
 Copyright (c) 2007 Aparecido Silva
 Virtual Mail 2.0
 E-mail: djsync@uol.com.br
 MSN: djsync@uol.com.br
 Por favor n�o tire os copyright �2007
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Virtual Mail</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-size: 9px}
-->
</style>
</head>

<body>
<table width="700" border="0" cellpadding="0" cellspacing="0" class="tbtop">
  <tr>
    <td width="21" class="stockWarning"><img src="img/mail.gif" width="16" height="16" /></td>
    <td width="209">Virtual Mail <span class="textdatatime"><strong>2.0</strong></span> Suporte </td>
    <td width="24" bgcolor="#FFFFFF" class="stockWarning"><img src="img/calendar.png" width="24" height="24" /></td>
    <td width="279" bgcolor="#FFFFFF" class="stockWarning"><span class="textdatatime">Data do Envio:</span>      <?
setlocale(LC_ALL, "portuguese"); // ou--> pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8",
echo strftime("%A, %d. %B %Y");
?> </td>
    <td width="20" bgcolor="#FFFFFF" class="stockWarning"><img src="img/r.gif" width="16" height="16" /></td>
    <td width="147" bgcolor="#FFFFFF" class="stockWarning"><span class="textdatatime">Hora:</span>    <?
setlocale(LC_ALL, "portuguese"); // ou--> pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8",
echo strftime("%H:%M:%S");
?></td>
  </tr>
</table>
<br />
<form id="fomulariosuporte" name="fomulariosuporte" method="post" action="enviar.php">
  <table width="700" border="0" cellpadding="5" cellspacing="1" class="tbtop">
    <tr>
      <td width="93" class="tbdown">Seu nome:</td>
      <td colspan="2" class="tbdown"><label>
        <input name="nome" type="text" class="bordaform" id="nome" />
      </label></td>
    </tr>
    <tr>
      <td class="tbdown">Seu e-mail:</td>
      <td colspan="2" class="tbdown"><label>
        <input name="email" type="text" class="bordaform" id="email" />
      </label></td>
    </tr>
    <tr>
      <td class="tbdown">Departamento:</td>
      <td colspan="2" class="tbdown"><select name="dep" id="dep">
        <option value="0">Selecione o Departamento</option>
        <option value="Suporte T&eacute;cnico">Suporte T&eacute;cnico</option>
          <option value="Departamento Financeiro">Departamento Financeiro</option>
          <option value="Informa&ccedil;&otilde;es Gerais">Informa&ccedil;&otilde;es Gerais</option>
        </select>      </td>
    </tr>
    <tr>
      <td class="tbdown">Assunto:</td>
      <td colspan="2" class="tbdown"><input name="ass" type="text" class="bordaform" id="ass" /></td>
    </tr>
    <tr>
      <td class="tbdown">Mensagem:</td>
      <td width="32" class="tbdown"><label></label>
      <img src="img/mini_ok.gif" width="24" height="24" /> </td>
      <td width="537" class="tbdown"><textarea name="men" cols="50" rows="5" class="bordaform" id="men"></textarea></td>
    </tr>
  </table>
  <p>
    <label>
    <input name="Submit" type="submit" class="enviar_mail" value="Enviar E-mail" />
    </label>
    <input name="Submit2" type="reset" class="enviar_mail" value="Limpar Formulario" />
  </p>
</form>
<p align="center" class="copyright style1">Powered By <a href="mailto:djsync@uol.com.br" class="textdatatime"><strong>Dj Sync</strong></a> &copy;2007 - Todos os direitos   reservados. </p>
</body>
</html>
