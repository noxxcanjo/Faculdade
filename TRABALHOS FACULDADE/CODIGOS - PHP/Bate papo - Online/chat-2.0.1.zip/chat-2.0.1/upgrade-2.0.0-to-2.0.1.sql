ALTER TABLE chatrooms ADD pos INT (10) not null , ADD created INT (20) not null;
ALTER TABLE chatusers ADD totalmsgs INT (20) not null , ADD creation DATE not null , ADD lastip CHAR (15) not null , ADD lasthost CHAR (100) not null, ADD ignorelist LONGTEXT not null;
CREATE TABLE msgs (
   datum date DEFAULT '0000-00-00' NOT NULL,
   uhrzeit time DEFAULT '00:00:00' NOT NULL,
   sentby varchar(100) NOT NULL,
   sentto varchar(100) NOT NULL,
   message text NOT NULL,
   id int(11) NOT NULL auto_increment,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

