<?
#########################################################################
#                                                                       #
#        Language File for                                              #
#        Mazen's PHP Chat V2                                            #
#                                                                       #
#  Language: English                                                    #
#  Authhor   : Marcel Beerta                                            #
#  EMail : beerta@weberweb.de                                           # 
#  URL   : http://www.beerta.de                                         #
#                                                                       #
#########################################################################

$suser_login      = "User Login";
$susername     = "Username";
$spassword     = "Password";
$sroom         = "Room";
$schatter      = "chatter";
$slogin        = "Login";
$snew_user     = "New User";
$semail        = "E-Mail";
$srealname     = "Real Name";
$screate_account  = "Create Account";
$sbad_email    = "You have entered an Incorrect E-Mail Adress";
$sbad_user     = "You've entered a wrong or empty Username";
$sbad_pass     = "You've entered a wrong or empty Password";
$sbad_realname    = "You've entered a wrong or empty Name";
$suser_exists     = "The username is already used by anothr";
$sbanned    = "You have been banned, and you can't chat for a while!<br>";
$sunbanned     = "You have been unbanned<br>";
$swronglogin      = "Wrong username/password combination.<br>Please go<a href=\"javascript:history.go(-1)\">back</a>";
$schatinput    = "Write Message";
$smiscellaneous      = "Misc";
$soptions      = "Options";
$slogout    = "Logout";
$sroomdescs    = "Chatrooms / Descriptions";
$sinside    = "In the Room";
$shacker    = "Sorry but you can't kick a user!";
$sjumproom     = "Go to Room:";
$sgoodreg      = "OK! You've been registered successfully!";
$shome         = "Back to the Login!";
$sentered      = "Chatbot: <b>$chatuser</b> has entered<br>";
$sleave        = "Chatbot: <b>$chatuser</b> has left<br>";
$scommandnothere  = "Chatbot: The given Command doesn't exist<br>";
$sisback    = "Chatbot: <b>$chatuser</b> is back<br>";
$sisaway    = "Chatbot: <b>$chatuser</b> is away!<br>";
$snorightvip      = "Chatbot: You don't have the rights to use Vip Commands<br>";
$snorightsu    = "Chatbot: You don't have the rights to use Superuser Commands<br>";
$svip       = " now has VIP rights<br>";
$snorm         = " has no rights anymore<br>";
$sop        = " now has Superuser rights<br>";
$sdownerr      = "You can't do that!<br>";
$sroomnotexists      = "The room $message doesn't exist!<br>";
$suserchangedroom = "Chatbot: <b>$chatuser</b> has changed the room<br>";
$sflisters     = "flisters:";
$shelp         = "Help";
$sroomisempty     = "The Chatroom is empty!<br>";
$suserbanned      = "The user has been banned<br>";
$suserunbanned    = "The user has been unbanned<br>";
$skicked    = "You have been kicked, and you can't chat anymore<br>";
$shasbeenkicked      = "has been kicked<br>";
$susernotinchat      = "The user is not in the Chat!<br>";
$susernotinroom      = "The user is not in this room!<br>";
$stoolonginactive = "You have been inactive too long!<br>";
$scolorchanged    = "Your color has been changed!";
$sinfoabout    = "Informations about $chatuser";
$spreferences     = "Useroptions for $chatuser";
$schangedata      = "Change";
$shpurl        = "Homepage URL";
$simgurl    = "Image URL";
$swmessage     = "Your Text";
$sguestbook ="Create Guestbook?";
$suserguestbook = "Guestbook from $chatuser";
$suserwriteguestbook = "Write in $chatuser's Guestbook";
$stitle  = "Title";
$stext   = "Message";
$sinsert = "Send";
$spassnotsame = "The Passwords don't match!";
$sselectcol = "Color";
$stop10 = "Top 10 of the Chatters:";

?>