<?
#########################################################################
#                                                                       #
#        Language File for                                              #
#        Mazen's PHP Chat V2                                            #
#                                                                       #
#  Language: French                                                     #
#  Author   : Marcel Beerta                                             #
#  EMail : beerta@weberweb.de                                           # 
#  URL   : http://www.mazenphp.de                                       #
#                                                                       #
#########################################################################

$suser_login      = "Utilisateur Login";
$susername     = "Nom de l'utilisateur";
$spassword     = "Mot de passe";
$sroom         = "Secteur";
$schatter      = "chatter";
$slogin        = "Login";
$snew_user     = "Plus � nouveau User";
$semail        = "E-Mail";
$srealname     = "Nom vrai";
$screate_account  = "enregistrer";
$sbad_email    = "Tu as indiqu� mauvais e-mail une adresse";
$sbad_user     = "Tu as indiqu� un nom de l'utilisateur mauvais ou vide";
$sbad_pass     = "Tu as indiqu� un mot de passe mauvais ou vide";
$sbad_realname    = "Tu as indiqu� un nom mauvais ou vide";
$suser_exists     = "Le nom de l'utilisateur souhait� existe d�j�";
$sbanned    = "Tu as �t� banni dans le Chat, et ne peus plus chatten!<br>";
$sunbanned     = "Tu veux parl� ebcore<br>";
$swronglogin      = "Mauvais de nom de l'utilisateur combinaison de mot de passe. Demande loge te de nouveau!<br><a href=\"javascript:history.go(-1)\">zur&uuml;ck</a>";
$schatinput    = " �crire une information";
$smiscellaneous      = "Divers";
$soptions      = "Options";
$slogout    = "Logout";
$sroomdescs    = "Chat�vacuent / descriptions";
$sinside    = "Dans le secteur";
$shacker    = "Sorry, toutefois un autre utilisateur  �liminer? Cela ne va pas! ";
$sjumproom     = "vont au secteur:";
$sgoodreg      = "OK!  Tu as �t� enregistr� avec succ�s!";
$shome         = "De retour au Login!";
$sentered      = "Information du Chatbot: <b>$chatuser</b>  a p�n�tr� juste le secteur<br>";
$sleave        = "Information du Chatbot: <b>$chatuser</b>  a quitt� juste le Chat<br>";
$scommandnothere  = "Information du Chatbot: Le commandement n'existe pas<br>";
$sisback    = "Information du Chatbot: <b>$chatuser</b> on se reconna�t<br>";
$sisaway    = "Information du Chatbot: <b>$chatuser</b> on se d�clare le d�part temporairement!<br>";
$snorightvip      = "Information du Chatbot: Tu ne dois pas exporter de droits autour des commandements VIP! <br>";
$snorightsu    = "Information du Chatbot: Tu ne dois pas exporter de droits autour des commandements d'utilisateur! <br>";
$svip       = " VIP a maintenant des droits<br>";
$snorm         = " n'a maintenant plus de droits sp�ciaux<br>";
$sop        = " l'utilisateur de Super a maintenant des droits<br>";
$sdownerr      = "Tu ne peus pas r�duire d'utilisateur plac� plus haut!<br>";
$sroomnotexists      = "Le secteur $message n'existe pas!<br>";
$suserchangedroom = "Information du Chatbot: <b>$chatuser</b>  a chang� le secteur<br>";
$sflisters     = "murmure:";
$shelp         = "L'aide";
$sroomisempty     = "Le Chatsecteur est vide!<br>";
$suserbanned      = "L'utilisateur a �t� banni<br>";
$suserunbanned    = "L'utilisateur est devenu lebanni<br>";
$skicked    = "Tu as �t� �limin�, et ne peus plus dans les Chat!<br>";
$shasbeenkicked      = "on a �limin�<br>";
$susernotinchat      = "L'utilisateur n'est pas dans le Chat!<br>";
$susernotinroom      = "L'utilisateur n'est pas dans ce secteur!<br>";
$stoolonginactive = "Tu �tais inactif longs, et ne peus pas par cons�quent plus loin chatten! <br>";
$scolorchanged    = "Tonne couleur a �t� modifi�e!";
$sinfoabout    = "Informations plus d' $chatuser";
$spreferences     = "Options d'utilisateur $chatuser";
$schangedata      = "Des donn�es modifier";
$shpurl        = "Homepage URL";
$simgurl    = "Image URL";
$swmessage     = "Ton slogan";
$sguestbook ="Le livre de h�te mettre?";
$suserguestbook = "Livre de h�te $chatuser";
$suserwriteguestbook = "Dans le livre de h�te $chatuser �crire";
$stitle  = "Titre";
$stext   = "Information";
$sinsert = "Une entr�e entreprendre";
$spassnotsame = "Les mots de passe sugg�r�s ne correspondent pas ensemble! ";
$sselectcol = "Couleur";
$stop10 = "Top 10 des Chatter dans les minutes:";

?>