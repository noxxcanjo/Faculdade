<?
#########################################################################
#                                                                       #
#        Language File for                                              #
#        Mazen's PHP Chat V2                                            #
#                                                                       #
#  Language: German                                                     #
#  Author   : Marcel Beerta                                             #
#  EMail : beerta@weberweb.de                                           # 
#  URL   : http://www.beerta.de                                         #
#                                                                       #
#########################################################################

$suser_login      = "User Login";
$susername     = "Username";
$spassword     = "Passwort";
$sroom         = "Raum";
$schatter      = "chatter";
$slogin        = "Login";
$snew_user     = "Neuer User";
$semail        = "E-Mail";
$srealname     = "Realer Name";
$screate_account  = "Create Account";
$sbad_email    = "Du hast eine falsche E-Mail Adresse angegeben";
$sbad_user     = "Du hast einen falschen oder leeren Usernamen angegeben";
$sbad_pass     = "Du hast ein falsches oder leeres Passwort angegeben";
$sbad_realname    = "Du hast einen falschen oder leeren Namen angegeben";
$suser_exists     = "Der gew&uuml;nschte Benutzername existiert bereits";
$sbanned    = "Du bist im Chat verbannt worden, und darfst nicht mehr chatten!<br>";
$sunbanned     = "Du bist wieder entbannt worden<br>";
$swronglogin      = "Falsche Benutzername- Passwortkombination. Bitte loge dich erneut ein!<br><a href=\"javascript:history.go(-1)\">zur&uuml;ck</a>";
$schatinput    = "Nachricht schreiben";
$smiscellaneous      = "Verschiedenes";
$soptions      = "Optionen";
$slogout    = "Logout";
$sroomdescs    = "Chatr&auml;ume / Beschreibungen";
$sinside    = "Im Raum";
$shacker    = "Sorry, aber einen anderen Benutzer rausschmei&szlig;en ? Das geht nicht!";
$sjumproom     = "Gehe zu Raum:";
$sgoodreg      = "OK! Du bist erfolgreich registriert worden!";
$shome         = "Zur&uuml;ck zum Login!";
$sentered      = "Nachricht vom Chatbot: <b>$chatuser</b> hat soeben den Raum betreten<br>";
$sleave        = "Nachricht vom Chatbot: <b>$chatuser</b> hat soeben den Chat verlassen<br>";
$scommandnothere  = "Nachricht vom Chatbot: Das Kommando existiert nicht<br>";
$sisback    = "Nachricht vom Chatbot: <b>$chatuser</b> meldet sich zur&uuml;ck<br>";
$sisaway    = "Nachricht vom Chatbot: <b>$chatuser</b> meldet sich vor&uuml;bergehend ab!<br>";
$snorightvip      = "Nachricht vom Chatbot: Du hast keine Rechte um VIP-Kommandos auszuf&uuml;hren!<br>";
$snorightsu    = "Nachricht vom Chatbot: Du hast keine Rechte um Superuser-Kommandos auszuf&uuml;hren!<br>";
$svip       = " hat jetzt VIP Rechte<br>";
$snorm         = " hat jetzt keine Sonderrechte mehr<br>";
$sop        = " hat jetzt Superuser Rechte<br>";
$sdownerr      = "Du kannst keinen h&ouml;her gestellten user heruntersetzen!<br>";
$sroomnotexists      = "Der Raum $message existiert nicht!<br>";
$suserchangedroom = "Nachricht vom Chatbot: <b>$chatuser</b> hat den Raum gewechselt<br>";
$sflisters     = "fl&uuml;stert:";
$shelp         = "Hilfe";
$sroomisempty     = "Der Chatraum ist leer!<br>";
$suserbanned      = "Der Benutzer wurde verbannt<br>";
$suserunbanned    = "Der Benutzer wurde entbannt<br>";
$skicked    = "Du bist entg&uuml;ltig rausgeschmissen worden, und kannst nicht mehr in den Chat!<br>";
$shasbeenkicked      = "ist rausgeschmissen worden<br>";
$susernotinchat      = "Der Benutzer ist nicht im Chat!<br>";
$susernotinroom      = "Der Benutzer ist nicht in diesem Raum!<br>";
$stoolonginactive = "Du warst zu lange Inaktiv, und kannst deshalb nicht weiterchatten!<br>";
$scolorchanged    = "Deine Farbe wurde ge�ndert!";
$sinfoabout    = "Informationen &uuml;ber $chatuser";
$spreferences     = "Useroptionen f&uuml; $chatuser";
$schangedata      = "Daten &auml;ndern";
$shpurl        = "Homepage URL";
$simgurl    = "Bild URL";
$swmessage     = "Dein Motto";
$sguestbook ="G�stebuch anlegen?";
$suserguestbook = "G�stebuch von $chatuser";
$suserwriteguestbook = "In's G�stebuch von $chatuser schreiben";
$stitle  = "Titel";
$stext   = "Nachricht";
$sinsert = "Eintrag vornehmen";
$spassnotsame = "Die eingegebenen Passw�rter stimmen nicht miteinander �berein!";
$sselectcol = "Farbe";
$stop10 = "Top 10 der Chatter in Minuten:";

?>