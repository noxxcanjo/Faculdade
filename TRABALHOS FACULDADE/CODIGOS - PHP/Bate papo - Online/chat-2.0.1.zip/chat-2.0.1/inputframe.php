<?

INCLUDE "./include/configuration.inc.php";
mt_srand((double)microtime()*1000000);
$header = new EasyTemplate("$basepath/templates/inputheader.tpl");
$header -> assign("TITLE",$title);
$header -> easy_print();
$usersip=getenv("REMOTE_ADDR"); 
$usersxforwarded=addslashes(getenv("HTTP_X_FORWARDED_FOR"));
$usershostname=addslashes(@GetHostByAddr($usersip));
?>
<script language="JavaScript">
function reloadusers()
{
    parent.frames[2].location.href="nicklist.php?chatuser=<? echo $chatuser ?>&chatroom=<? echo $chatroom ?>";
}
function setsmiley(what)
{
	document.inputForm.text2.value = document.inputForm.elements.text2.value+" "+what;
	document.inputForm.text2.focus();
}

</script>    
<table border=0 width=100% cellspacing=2 cellpadding=0>
<tr>
    <td width=70% valign=top nowrap>
<?
$tblheader -> assign("TBLTITLE",$schatinput);
$tblheader -> assign("WIDTH","100%");
$tblheader -> assign("ALIGN","center");
$tblheader -> easy_print();
?>
<form name="inputForm" method=POST action="chatinput.php" target="dummy" onsubmit="reloadusers();resetinput(); return false;"">
<input type=hidden name=usersip value="<? echo $usersip ?>">
<input type=hidden name=usersxforwarded value="<? echo $usersxforwarded ?>">
<input type=hidden name=usershostname value="<? echo $usershostname ?>">
<input type=hidden name=chatuser value="<? echo $chatuser ?>">
<input type=hidden name=userpass value="<? echo $userpass ?>">
<input type=hidden name=chatroom value="<? echo $chatroom ?>">
<input type=hidden name=text value="">
<input type=text name=text2 value="" size=45 maxlength=255><br>
<?
if($emoticons):
?>
<a href="javascript:setsmiley(':)')"><img src="images/smile.gif" border=0></a>
<a href="javascript:setsmiley(':(')"><img src="images/frown.gif" border=0></a>
<a href="javascript:setsmiley(':o')"><img src="images/redface.gif" border=0></a>
<a href="javascript:setsmiley(':D')"><img src="images/biggrin.gif" border=0></a>
<a href="javascript:setsmiley(':ent:')"><img src="images/blue.gif" border=0></a>
<a href="javascript:setsmiley(':shy:')"><img src="images/shy.gif" border=0></a>
<a href="javascript:setsmiley(':sleepy:')"><img src="images/sleepy.gif" border=0></a>
<a href="javascript:setsmiley(':sun:')"><img src="images/sunglasses.gif" border=0></a>
<a href="javascript:setsmiley(':sg:')"><img src="images/supergrin.gif" border=0></a>
<a href="javascript:setsmiley(':embarass:')"><img src="images/embarass.gif" border=0></a>
<a href="javascript:setsmiley(':dead:')"><img src="images/dead.gif" border=0></a>
<a href="javascript:setsmiley(':cool:')"><img src="images/cool.gif" border=0></a>
<a href="javascript:setsmiley(':clown:')"><img src="images/clown.gif" border=0></a>
<a href="javascript:setsmiley(':pukey:')"><img src="images/pukey.gif" border=0></a>
<a href="javascript:setsmiley(':eek:')"><img src="images/eek.gif" border=0></a>
<a href="javascript:setsmiley(':roll:')"><img src="images/sarcblink.gif" border=0></a>
<a href="javascript:setsmiley(':smoke:')"><img src="images/smokin.gif" border=0></a>
<a href="javascript:setsmiley(':bounce:')"><img src="images/bounce.gif" border=0></a>
<a href="javascript:setsmiley(':angry:')"><img src="images/reallymad.gif" border=0></a>
<a href="javascript:setsmiley(':confused:')"><img src="images/confused.gif" border=0></a>
<a href="javascript:setsmiley(':cry:')"><img src="images/crying.gif" border=0></a>
<a href="javascript:setsmiley(':lol:')"><img src="images/lol.gif" border=0></a>
<a href="javascript:setsmiley(':yawn:')"><img src="images/yawn.gif" border=0></a>
<a href="javascript:setsmiley(':devil:')"><img src="images/devil.gif" border=0></a>
<a href="javascript:setsmiley(':tongue:')"><img src="images/tongue.gif" border=0></a>
<a href="javascript:setsmiley(':alien:')"><img src="images/aysmile.gif" border=0></a>
<a href="javascript:setsmiley(':tasty:')"><img src="images/tasty.gif" border=0></a>
<a href="javascript:setsmiley(':crazy:')"><img src="images/grazy.gif" border=0></a>
</form><?
endif;
$tblfooter -> easy_print();
?>
    </td>
    <td width=10% valign=top>
    <?
    $tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");
    $tblheader -> assign("WIDTH","100%");
    $tblheader -> assign("ALIGN","center");
    $tblheader -> assign("TBLTITLE",$sselectcol);
    $tblheader -> easy_print();
    include "colors.php";
    $tblfooter -> easy_print(); 
     ?>
    </td>
    <td width=20% valign=top>
<?
    $tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");
    $tblheader -> assign("WIDTH","100%");
    $tblheader -> assign("ALIGN","center");
    $tblheader -> assign("TBLTITLE",$smiscellaneous);
    $tblheader -> easy_print();
?>
    <a href="useroptions.php?chatuser=<? echo $chatuser ?>&userpass=<? echo $userpass ?>" target=_blank><? echo $soptions ?></a><br>
    <a href="logout.php?chatuser=<? echo $chatuser ?>&userpass=<? echo $userpass ?>&chatroom=<? echo $chatroom ?>" target=output><? echo $slogout ?></a><br>
    <a href="help/<? echo $language ?>_index.html" target=_blank><? echo $shelp ?></a>
<?
    $tblfooter -> easy_print();
?>
    </td>
</tr>
</table>
<?
$footer -> easy_print();
?>