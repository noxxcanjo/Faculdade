<?
INCLUDE "../include/configuration.inc.php";
$header -> assign("BODY","");
$header -> assign("URL","$baseurl/");
$header -> easy_print();

$db = new db_local;
if($user== $adminuser && $pass == $adminpass)
{
	if($action=='crtables')
	{
		$query="CREATE TABLE chatrooms (
   			name varchar(50) NOT NULL,
   			descr text NOT NULL,
   			pos int(11) NOT NULL,
   			created int(20) NOT NULL,
	   		PRIMARY KEY (name),
   			KEY name (name),
   			UNIQUE name_2 (name)
			)
			";
		$db->query($query);
		$query="CREATE TABLE chatusers (
					nick varchar(20) NOT NULL,
   					pass varchar(30) NOT NULL,
   					room varchar(50) NOT NULL,
   					name varchar(50) NOT NULL,
   					email varchar(50) NOT NULL,
   					active tinyint(1) NOT NULL,
   					away tinyint(1) NOT NULL,
   					banned tinyint(1) NOT NULL,
   					mode tinyint(1) NOT NULL,
   					lastaction int(20) NOT NULL,
   					hpurl varchar(100) NOT NULL,
   					imgurl varchar(100) NOT NULL,
   					col varchar(6) DEFAULT '$deftextcol' NOT NULL,
   					text text NOT NULL,
   					guestbook tinyint(1) NOT NULL,
   					totaltime int(20) NOT NULL,
   					totalmsgs int(20) NOT NULL,
   					creation date DEFAULT '0000-00-00' NOT NULL,
   					lastip varchar(15) NOT NULL,
   					lasthost varchar(100) NOT NULL,
   					ignorelist longtext NOT NULL,
   					PRIMARY KEY (nick),
   					KEY nick (nick),
   					UNIQUE nick_2 (nick, email)
				)";
		$db->query($query);
		$query="CREATE TABLE chatusers_gb (
		   owner varchar(20) NOT NULL,
	   	von varchar(20) NOT NULL,
	   	title varchar(255) NOT NULL,
	   	text text NOT NULL
			)
			";
		$db->query($query);
		$query="CREATE TABLE msgs (
		    datum date DEFAULT '0000-00-00' NOT NULL,
   			uhrzeit time DEFAULT '00:00:00' NOT NULL,
   			sentby varchar(100) NOT NULL,
   			sentto varchar(100) NOT NULL,
   			message text NOT NULL,
   			id int(11) NOT NULL auto_increment,
   			PRIMARY KEY (id),
   			KEY id (id),
   			UNIQUE id_2 (id)
			)";
		$db->query($query);


	}
	else if ($action=="crrooms")
	{
		if($subaction=="create")
		{
			$desc = nl2br($desc);
			
			
			$query="CREATE TABLE chatmessages_$room (
			  	id int(10) NOT NULL auto_increment,
   				message longtext NOT NULL,
   				user varchar(250),
   				datum date DEFAULT '0000-00-00' NOT NULL,
   				ip varchar(15) NOT NULL,
   				xforwarded text NOT NULL,
   				hostname varchar(100) NOT NULL,
   				PRIMARY KEY (id),
   				KEY id (id),
   				UNIQUE id_2 (id))
				";
			$db->query($query);
			$query="INSERT INTO chatrooms(name,descr) VALUES('$room','$desc')";
			$db->query($query);
			echo"Room Created successfully";
		}
		else
		{
		echo"
			<center>
			<form method=POST action=\"$PHP_SELF\">
			<input type=hidden name=user value=$user>
			<input type=hidden name=pass value=$pass>
			<input type=hidden name=action value=crrooms>
			<input type=hidden name=subaction value=create>
			Roomname: (The Only allowed Special character is the _ (underscore)!!!)<br>
			<input type=text name=room><br>
			Description:<br>
			<textarea name=desc rows=10 cols=50 wrap=virtual></textarea><br><br>
			<input type=submit value=\"Create Room\">
			</form>
			</center>
		";
		}
	}
	else if($action==eprooms)
	{
		$query="SELECT name FROM chatrooms";
		$db->query($query);
		$db2 = new db_local;
		while($db->next_record())
		{
			$room=$db->record[name];
			$db2->query("DELETE FROM chatmessages_$room");
		}
		echo"Chatlogs where flushed!";
	}
	else if ($action==mkadmin && $userpass==$userpass2)
	{
		$passwd = CRYPT ($userpass,"CRYPT_MD5");
		$db->query("INSERT INTO chatusers (nick,pass,room,name,email,mode) VALUES ('$chatuser','$passwd','','$realname','$useremail','2')");	
		echo"Admin Created Successfully!";
	}
	
	else
	{
		echo"
			<center>
			<form method=POST action=\"$PHP_SELF\">
			<input type=hidden name=user value=$user>
			<input type=hidden name=pass value=$pass>
			<input type=hidden name=action value=crtables>
			<input type=submit value=\"CREATE ALL TABLES\">
			</form>
			
			<form method=POST action=\"$PHP_SELF\">
			<input type=hidden name=user value=$user>
			<input type=hidden name=pass value=$pass>
			<input type=hidden name=action value=crrooms>
			<input type=submit value=\"CREATE NEW CHATROOM\">
			</form>
						
			<form method=POST action=\"$PHP_SELF\">
			<input type=hidden name=user value=$user>
			<input type=hidden name=pass value=$pass>
			<input type=hidden name=action value=eprooms>
			<input type=submit value=\"CLEAR ALL CHATLOGS\">
			</form>
			";
			?>
			<form method=POST action="<? echo $PHP_SELF ?>">
			<input type=hidden name=user value=<? echo $user ?>>
			<input type=hidden name=pass value=<? echo $pass ?>>
			<input type=hidden name=action value=mkadmin>
			<table border=0 width=100% cellspacing=0 cellpadding=0>
			<tr>
				<th colspan=2>Create New Superuser</th>
			</tr>
			<tr>
    			<td align=right><? echo $susername ?>:</td>
    			<td><input type=text name=chatuser value="<? echo $cusername; ?>" maxlength=20></td>
			</tr>
			<tr>
    			<td align=right><? echo $spassword ?>:</td>
    			<td><input type=password name=userpass maxlength=10></td>
			</tr>
			<tr>
    			<td align=right><? echo $spassword ?>:</td>
    			<td><input type=password name=userpass2 maxlength=10></td>
			</tr>
			<tr>
			    <td align=right><? echo $srealname ?>:</td>
    			<td><input type=text name=realname maxlength=50 value="<? echo $crealname ?>"></td>
			</tr>
			<tr>
			    <td align=right><? echo $semail ?>:</td>
    			<td><input type=text name=useremail maxlength=50 value="<? echo $cuseremail ?>"></td>
			</tr>
			<tr>
    			<td colspan=2 align=center><input type=submit value="<? echo $screate_account; ?>"></td>
			</tr>
			</table>
			</form>
			</center>
			<?
	}
}
else
{
	echo"
		<form method=POST action=\"$PHP_SELF\">
		<table border=0 align=center cellspacing=0 cellpadding=0>
		<tr>
			<td align=right width=20%>Adminuser: </td>
			<td width=80%><input type=text name=user></td>
		</tr>
		<tr>
			<td align=right>Adminpass: </td>
			<td><input type=password name=pass></td>
		</tr>
		<tr>
			<th colspan=2><input type=submit value=\"Login\"></th>
		</table>
		</form>
	";
}

$footer -> easy_print();
?>