<?

// gibt 1 aus, wenn die url erreichbar ist
function urlcheck($url) {
	if( !($fp = @fopen("$url", "r")) ) {
    $fehler=0;
  } else {
    $fehler=1;
  }
  return $fehler;
}

INCLUDE "./include/configuration.inc.php";
$header -> easy_print();

$db = new db_local;
$db -> query("SELECT * FROM chatusers WHERE nick = '$chatuser'");
$db -> next_record();
$dbpass = $db->record[pass];

if ($userpass == $dbpass && $action=="change")
{
    $name = strip_tags($name);
    $email = strip_tags($email);
    $hpurl = strip_tags($hpurl);
    $bildurl = strip_tags($bildurl);
    $text = strip_tags($text);
    $text = nl2br($text);
    if ($guestbook == "on") $guestbook = 1;
    else $guestbook = 0;
    $db -> query("UPDATE chatusers SET name='$name', email = '$email', hpurl='$hpurl', imgurl='$bildurl' , text='$text', guestbook='$guestbook' WHERE nick='$chatuser'");
}
if ($action == "addgb")
{
	$titel = strip_tags($titel);
	$text = strip_tags($text);
	$text = nl2br($text);
	$db -> query("INSERT INTO chatusers_gb (owner,von,title,text) VALUES ('$chatuser','$von','$titel','$text')");
}


$db -> query("SELECT * FROM chatusers WHERE nick = '$chatuser'");
$db -> next_record();

    $bildurl = $db->record[imgurl];
    $hpurl = $db->record[hpurl];
    $lastip = $db->record[lastip];
    $lasthost = $db->record[lasthost];
    $totalmsgs = $db->record[totalmsgs];
    $text = $db->record[text];
    $mail = $db->record[email];
    $name = $db->record[name];
    $status = $db->record[mode];
    $lastaction = date("d.m.Y H:i:s",$db->record[lastaction]);
    $time=sprintf("%.0lf",$db->record[totaltime]/60);
    $guestbook = $db->record[guestbook];
    $tblheader -> assign("TBLTITLE","$sinfoabout");
    $tblheader -> assign("WIDTH","80%");
    $tblheader -> assign("ALIGN","center");
    $tblheader -> easy_print();
    if ($status=="" || $status=="0") {$status="Normaler User";}
    else if ($status==1) {$status="VIP";}
    else if ($status==2) {$status="OP (Admin)";}



    ?>
    <table border=0 width=100% cellspacing=0 cellpadding=0>
    <tr>
	<td valign=top>
	<?
	    if (!empty($hpurl))
	    echo "Homepage: <a href=\"$hpurl\" target=_blank>$hpurl</a><br>";
 echo "eMail: <a href=\"mailto:$mail\">$mail</a><br>";	
 echo "Status: $status<br>";
 echo "Chatzeit: $time Minuten ($totalmsgs Postings)<br>";
 echo "Zuletzt online: $lastaction<br>";
 echo "IP: $lastip<br>";
 echo "Host: $lasthost<br>";
    if (!empty($bildurl))
    echo "<br><img src=\"$bildurl\" border=0 valign=10 halign=10><br>";
 echo "<br>$text";

?>
	</td>
    </tr>
    </table>
    <?	
	$tblfooter -> easy_print();

	echo "<br><br>";

if ($guestbook == 1)
{
	$tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");
	$tblheader -> assign("TBLTITLE",$suserguestbook);
	$tblheader -> assign("WIDTH","80%");
	$tblheader -> assign("ALIGN","center");
	$tblheader -> easy_print();
	
	$db -> query("SELECT * FROM chatusers_gb WHERE owner = '$chatuser'");
	while ($db->next_record())
	{
		
		echo "<b>".$db->record[title]." von ".$db->record[von]."</b><br>".$db->record[text]."<br><br>";
		
	}
	$tblfooter -> easy_print();	
	
	echo "<br><br>";
	
	$tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");
	$tblheader -> assign("TBLTITLE",$suserwriteguestbook);
	$tblheader -> assign("WIDTH","80%");
	$tblheader -> assign("ALIGN","center");
	$tblheader -> easy_print();
	?>
	<form method=POST action="<? echo $PHP_SELF?>">
	<input type=hidden name=von value="<? echo $suser ?>">
	<input type=hidden name=chatuser value="<? echo $chatuser ?>">
	<input type=hidden name=action value=addgb>
	
	<table border=0 width=100% cellspacing=0 cellpadding=0>
	<tr>
		<td width=20% align=right><? echo $stitle ?>:</td>
		<td width=80%><input type=text name=titel></td>
	</tr>
	<tr>
		<td align=right valign=top><? echo $stext ?>:</td>
		<td><textarea name=text rows=10 cols=50 wrap=virtual></textarea></td>
	</tr>
	<tr>
		<td colspan=2 align=center><input type=submit value="<? echo $sinsert ?>"></td>
	</tr>
	</table>
	</form>
	<?
	$tblfooter -> easy_print();	
	
	
}


if(!empty($userpass))
{
	if ($guestbook == 1)
	{
		$chk = 'checked';
	}
    echo "<br><br>";
    if ($dbpass == $userpass)
    {
	$tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");
	$tblheader -> assign("TBLTITLE",$spreferences);
	$tblheader -> assign("WIDTH","80%");
	$tblheader -> assign("ALIGN","center");
	$tblheader -> easy_print();
	?>
	<form method=POST action=<? echo $PHP_SELF ?>>
	<input type=hidden name=chatuser value="<? echo $chatuser ?>">
	<input type=hidden name=userpass value="<? echo $userpass ?>">
	<input type=hidden name=action value="change">
	<table border=0 width=100% cellspacing=0 cellpadding=0>
	<tr>
	    <td width=20% align=right><? echo $srealname ?>:</td>
	    <td width=80%><input type=text name=name value="<? echo $name ?>"></td>
	</tr>
	<tr>
	    <td align=right><? echo $semail ?>:</td>
	    <td><input type=text name=email value="<? echo $mail ?>"></td>
	</tr>
	<tr>
	    <td align=right><? echo $shpurl ?>:</td>
	    <td><input type=text name=hpurl value="<? echo $hpurl ?>"> *</td>
	</tr>
	<tr>
	    <td align=right><? echo $simgurl ?>:</td>
	    <td><input type=text name=bildurl value="<? echo $bildurl ?>"> *</td>
	</tr>
	<tr>
	    <td valign=top align=right><? echo $swmessage ?>:</td>
	    <td><textarea name=text rows=10 cols=50 wrap=virtual><? echo strip_tags($text) ?></textarea></td>
	</tr>


	<tr>
		<td align=right><? echo $sguestbook ?>:</td>
		<td><input type=checkbox name=guestbook <? echo $chk ?>></td>
	</tr>


	<tr>
	    <td colspan=2 align=center><input type=submit value="<? echo $schangedata ?>"></td>
	</tr>
	</table>
<br>* Die Links auf die Homepage und die Grafik werden nur angezeigt, wenn die Homepage und die Grafik auch vorhanden und erreichbar sind. Es bringt also nix hier etwas einzutragen was es nicht gibt, da die Info-Seite das dann einfach ignorieren w&uuml;rde :)
	</form>
	<?
	$tblfooter -> easy_print();
    }
    else
    {
        echo "<center>$swronglogin</center>";
    }
}
	$footer -> easy_print();
//$db->close();
?>