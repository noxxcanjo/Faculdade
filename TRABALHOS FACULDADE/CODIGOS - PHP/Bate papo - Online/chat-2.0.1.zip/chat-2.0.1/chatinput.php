<?
INCLUDE "./include/configuration.inc.php";
$db = new db_local;
$db->query("SELECT * FROM chatusers WHERE nick = '$chatuser'");
$db->next_record();
$pass = $db->record[pass];
$mode = $db->record[mode];
$col = $db->record[col];
$away = $db->record[away];

$message = strip_tags($text);

# Because of Read/Write actions on the table, we wait a little time before posing
# so it's safe, that any message will get into the table ...
mt_srand((double)microtime()*1000000);
$randval = mt_rand(100000,500000);
usleep($randval);

# When user selects his color in the bottom frame, $farbe is filled
# So we set a message that matches the /col command

if(!empty($farbe)) { $message = "/col $farbe"; $col = $farbe; }

if(!empty($message))
{
	if($pass == $userpass && $db->record[banned] == '0' && $db->record[active] == '1')
	{
		$msgprefix = "<font color=\"#$col\">";
		$msgpostfix = " </font><br>";
//		$msgpostfix = " </font>";
		
		if ($away==1)
		{
			# First we check if user is away ...
			# If yes we have to send a back-msg
			$lastaction = time();
			$db->query("UPDATE chatusers SET away = '0', lastaction = '$lastaction' WHERE nick = '$chatuser'");
			$db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$fontprefix2 $sisback </font>','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
			usleep(500000);
		}
		
		# Now we beginn checking the commands and include the command matching file
		
		if(eregi("^/",$message))
		{
			#A Command is given ...
			include "./include/commands.php";
		}
		else if (eregi("^\+",$message))
		{
			if($mode >=1)
			{
				#It's a VIP-Command
			include "./include/commands_vip.php";
			}
			else
			{
				$msg = "privatemessagestring $chatuser -&gt; $snorightvip";
				$nodate=1;
			}
			
		}
		else if (eregi("^\@",$message))
		{
			if($mode >=2)
			{
				#It's an Admin Command
				include "./include/commands_admin.php";
			}
			else
			{
				$msg = "privatemessagestring $chatuser -&gt; $snorightsu";
                                $nodate=1;
			}
			
		}
		else
		{
			$message = ereg_replace("\*([^\*]+)\*","<b>\\1</b>",$message);
			$message = ereg_replace("_([^_]+)_","<u>\\1</u>",$message);
			$message = ereg_replace("#([^#]+)#","<i>\\1</i>",$message);
			if (eregi(":",$message))
			{
			#It's one of the smileys or a link
		
 				if(eregi("http://",$message))
				{
					$message = eregi_replace("(http://[^\n< ]+)","<a href=\"\\1\" target=\"_blank\" title=\"\\1 &ouml;ffnen\">\\1</a>",$message);
					$message=addslashes($message);
					$msg="$msgprefix $message $msgpostfix";
				}
				
				else if(eregi("ftp://",$message))
				{
					$message = eregi_replace("(ftp://[^\n< ]+)","<a href=\"\\1\" target=_blank>\\1</a>",$message);
					$message=addslashes($message);
					$msg="$msgprefix $message $msgpostfix";
				}
				if ($emoticons)
				{
					include "./include/commands_smileys.php";
				}
			
			}
			if (empty($msg))
			{
				$msg = $msgprefix." ".$message." ".$msgpostfix;
			}		}
		
    if ($msg != "" && $nodate!=1) {
      // Bei Away etc. wird keine Message ausgegeben
      $msg= date('H:i:s')." ".$chatuser." &gt;&nbsp;".$msg;
    }
//    $msg="<font size=\"3\" face=\"Arial,Helvetica,Helv\">".$msg."</font>";
//    $msg="<pre>".$msg."</pre>";
    $msg=$fontprefix.$msg."</font>";
		$time = time();
		$db->query("SELECT lastaction,totaltime,totalmsgs FROM chatusers WHERE nick = '$chatuser'");
		$db->next_record();
		$lastaction = $db->record[lastaction];
		$totalmsgs = $db->record[totalmsgs];
		$totaltime = $db->record[totaltime];
		$secs = $time - $lastaction;
		$tot = $totaltime + $secs;
		$totalmsgs++;
//		$db->query("LOCK TABLES chatmessages_$chatroom WRITE,chatusers WRITE");		      
		$db->query("UPDATE chatusers SET lastaction='$time', totaltime='$tot', lastip='$usersip', lasthost='$usershostname', totalmsgs='$totalmsgs' WHERE nick = '$chatuser'");		
		$db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$msg','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
//                $db->query("UNLOCK TABLES");
	}
}
$db->close();
?>
<html>
<script language="javascript">
<!--
  parent.frames[3].document.inputForm.text2.value = '';
  parent.frames[3].document.inputForm.text2.focus();
  parent.frames[3].document.inputForm.text2.select();
//-->
</script>
</html>