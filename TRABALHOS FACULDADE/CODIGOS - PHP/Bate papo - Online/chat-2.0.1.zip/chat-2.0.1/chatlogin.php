<?
$chatuser=strtolower($chatuser);
INCLUDE "./include/configuration.inc.php";
$db = new db_local;
	if (!empty($chatuser))
	{
		
		$db -> query("SELECT * FROM chatusers WHERE nick = '$chatuser'");
		if($db->num_rows()>0)
		{
			$db -> next_record();
			if(!empty($userpassw))
			{
				$userpass = crypt($userpassw,"CRYPT_MD5");
			}
			$dbpass = $db->record[pass];
			$banned = $db->record[banned];
			$active = $db->record[active];
			if ( $dbpass == $userpass && $banned == '0')
			{
				$time = time();
				# User entered correct Username/Password combination and is not banned
				$db->query("UPDATE chatusers SET away = '0' , active = '1', room = '$chatroom', lastaction = '$time' WHERE  nick = '$chatuser'");
				if($active!=1)
				{
					$db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$fontprefixa $sentered </font>','$chatuser','$date','','','')");


$usersip=getenv("REMOTE_ADDR"); 
$usershostname=addslashes(@GetHostByAddr($usersip));

if ($usersip!="" or $usershostname!="") {
	$db->query("SELECT nick FROM chatusers where (lastip='$usersip' or lasthost like '%$usershostname%') and banned=1 order by lastaction desc limit 1");
	if($db->num_rows()>0)
	{
		$nick = $db->record[nick];
		
	}
}



				}
				echo"
				<html>
				<head>
				<title>$title</title>
				<script language=\"JavaScript\">
				<!--
				if(top.frames.length > 0)
				{
					top.location.href=self.location;
				}
				//-->
				</script>
				</head>
				<frameset rows=\"75,*,120,0\" frameborder=0 border=0 framespacing=0>
					<frame name=roomlist src=\"chatrooms.php?chatuser=$chatuser&userpass=$userpass&chatroom=$chatroom\" scrolling=no>
				<frameset cols=\"*,150\">
					<frame name=output src=\"outputframe.php?chatuser=$chatuser&chatroom=$chatroom&userpass=$userpass\" scrolling=auto>
					<frame name=nicklist src=\"nicklist.php?chatuser=$chatuser&chatroom=$chatroom\" scrolling=no>
				</frameset>
					<frame name=input src=\"inputframe.php?chatuser=$chatuser&userpass=$userpass&chatroom=$chatroom\" scrolling=no>
					<frame name=dummy src=\"dummy.html\" scrolling=no noresize>
				</frameset>
				</html>
				"; 	   
			}
			else if ($banned == '1')
			{
				$header -> easy_print();
				echo $sbanned;
				$footer -> easy_print();
			}
			else
			{
				$header -> easy_print();
				echo $swronglogin;
				$footer -> easy_print();
			}
		}
		else
		{
			$header -> easy_print();
			echo $swronglogin;
			$footer -> easy_print();
		}
	}
	else
	{
		$header -> easy_print();
		echo $swronglogin;
		$footer -> easy_print();
	}

	
?>