<?

INCLUDE "./include/configuration.inc.php";

$db = new db_local;
$db2 = new db_local;

  $db -> query("SELECT * FROM chatusers WHERE nick = '$chatuser'");
  $db -> next_record();
  $pass = $db->record[pass];
  if ( $pass == $userpass )
  {
      if($db->record[mode] == '1')
      {
  	$mode = 0;
      }
      else
      {
  	$mode = $db->record[mode];
      }
      
      $db->query("UPDATE chatusers SET active = '0', away = '0', mode = '$mode' WHERE nick = '$chatuser'");
      $db->query("INSERT INTO chatmessages_$chatroom VALUES('','$fontprefixb $sleave </font>','$chatuser','$date','','','')");
      
    echo $logoutmsg;
  }
  else
  {
      # Someone tryed to kick a user .
//      echo $shacker;
  }


?>