<?

INCLUDE "./include/configuration.inc.php";
$header -> assign("BODY","");
$header -> easy_print();

if(!eregi("sep_",$chatroom))
{
	$tblheader -> assign("TBLTITLE",$chatroom);
}
else
{
	$tblheader -> assign("TBLTITLE","Separee");
}

$tblheader -> assign("WIDTH","100%");
$tblheader -> assign("ALIGN","center");
$tblheader -> easy_print();

$db = new db_local;
$db2 = new db_local;
$time = time();


// Separees loeschen
$db->query("select unix_timestamp()-3600");
$timestamp = $db->result();
#$timestamp=mysql_result(mysql_query("select unix_timestamp()-3600"),0,0); // Aktuelle Zeit minus 120 Minuten
$db -> query("SELECT name FROM chatrooms where name like 'sep_%' and created<$timestamp"); // Alle Separees auswaehlen, die vor 60 minuten und frueher erzeugte wurden (Verzoegerung, damit nicht in dem moment, in dem in den erstellten raum gewechselt wird, der raum geloescht wird oder ein sich ganz spaet entscheidender in einen nicht mehr existierenden raum wechseln will :))
while ($db->next_record())
{
    $room = $db->record[name];
    $db2->query("SELECT count(*) FROM chatusers WHERE active = '1' AND room = '$room'");
    $num =$db2->result();
    if ($num==0) {
      $db2->query("drop table if exists chatmessages_$room");
      $db2->query("delete from chatrooms where name='$room'");
    }
}

// User im aktuellen Raum anzeigen
$time = time();
$query = "SELECT lastaction,room,nick,imgurl,away,mode FROM chatusers where active = '1' ORDER BY mode DESC, nick";
$db -> query($query);


while($db->next_record())
{
    $room = $db->record[room];
    $nick = $db->record[nick];
    $imgurl = $db->record[imgurl];
    $away = $db->record[away];
    $status = $db->record[mode];


    // Autokick
    $onl = $time - $db->record[lastaction];
    $min = $onl/60;
    $min = sprintf("%.0lf",$min);
    
    if($min>10)
    {
			#User has been very long inactive, so we check if he's away or not, so we can kick him ...
			if($away=='0')
			{
			    # User is not away, so lets kick him ...
	    		$db2->query("UPDATE chatusers SET active='0' WHERE nick = '$nick'");
			}
			else if($min>30 && $away=='1')
			{
				# User is away, but has been inactive since 4 hours!
				# Too long, so say goodbye ;-)
				$db2->query("UPDATE chatusers SET active='0' WHERE nick = '$nick'");
			}
			else
			{
					# User is away, but under $maxaway Minutes, he may stay
					$flag = 'ok';
			}
    }
    else
    {
			$flag='ok';
    }
    // Ende Autokick

    
    
    if ($flag=='ok')
    {
			if ($status=='0')
			{
	    		# User is in normal mode
	    		$mode = "";
			}
			else if ($status=='1')
			{
			   # User is VIP
	    		$mode = "+";
			}
			else if ($status=='2')
			{
	    		# User is Superuser
	    		$mode = "@";
			}

			if ($away=='1' && $room==$chatroom)
			{
	    		echo "&middot;&nbsp;".$mode."<i><a href=\"useroptions.php?suser=$chatuser&chatuser=".$nick."\" target=_blank $titletext>".$nick."</a> ($min)</i><br>";
			}
			elseif ($away!='1' && $room==$chatroom)
			{
	    		echo "&middot;&nbsp;".$mode."<a href=\"useroptions.php?suser=$chatuser&chatuser=".$nick."\" target=_blank $titletext>".$nick."</a> ($min)<br>";
			}
    }

}




$tblfooter -> easy_print();

$footer -> easy_print();

/*
die nicklist aktualisiert sich normalerweise alle 20 sekunden und hat damit einen anteil von 60% am gesamttraffic des chatsystems, was natuerlich eher schlecht ist, weil es unverschaemt viel geld kostet. dies laesst sich folgendermassen optimieren:

Vielen Dank an Oliver Kurlvink
http://www.metal.de
*/

$reload=20000;
$time = time();
$query = "SELECT lastaction,away FROM chatusers where nick = '$chatuser'";
$db -> query($query);
$db->next_record();
$away = $db->record[away];
$onl = $time - $db->record[lastaction];
$min = $onl/60;
$min = number_format($min);
//print $away;
//print $min;
// oeffentlicher raum
if (!ereg("sep_",$chatroom)) {
  // user online
  if ($away!='1') {
        if ($min<2) {$reload=20000;} // unter 2 mins idle 20 sekunden intervall
    elseif ($min<4) {$reload=30000;} // unter 4 mins idle 30 sekunden intervall
    elseif ($min<6) {$reload=40000;} // unter 6 mins idle 40 sekunden intervall
    elseif ($min<11) {$reload=60000;} // unter 11 mins idle 60 sekunden intervall
    elseif ($min<16) {$reload=80000;} // unter 16 mins idle 80 sekunden intervall
    elseif ($min<31) {$reload=120000;} // unter 31 mins idle 120 sekunden intervall
    else {$reload=240000;} // fuer den rest 240 sekunden. da autokick auf 30 minuten steht duerfte dieser fall niemals auftreten
  // user away
  } else {
        if ($min<11) {$reload=80000;} // unter 11 mins idle 80 sekunden intervall
    elseif ($min<16) {$reload=120000;} // unter 16 mins idle 120 sekunden intervall
    elseif ($min<21) {$reload=140000;} // unter 21 mins idle 140 sekunden intervall
    elseif ($min<31) {$reload=180000;} // unter 31 mins idle 180 sekunden intervall
    elseif ($min<46) {$reload=240000;} // unter 46 mins idle 240 sekunden intervall
    elseif ($min<241) {$reload=300000;} // unter 4h idle 5 minuten intervall
    else {$reload=240000;} // fuer den rest 240 sekunden. da autikick auf 240 minuten steht duerfte dieser fall niemals auftreten
  }
// privater raum
} else {
  // user online
  if ($away!='1') {
        if ($min<11) {$reload=60000;} // unter 11 mins idle 60 sekunden intervall
    elseif ($min<16) {$reload=80000;} // unter 16 mins idle 80 sekunden intervall
    elseif ($min<31) {$reload=120000;} // unter 31 mins idle 120 sekunden intervall
    else {$reload=240000;} // fuer den rest 240 sekunden. da autokick auf 30 minuten steht duerfte dieser fall niemals auftreten
  // user away
  } else {
        if ($min<16) {$reload=120000;} // unter 16 mins idle 120 sekunden intervall
    elseif ($min<21) {$reload=140000;} // unter 21 mins idle 140 sekunden intervall
    elseif ($min<31) {$reload=180000;} // unter 31 mins idle 180 sekunden intervall
    elseif ($min<46) {$reload=240000;} // unter 46 mins idle 240 sekunden intervall
    elseif ($min<241) {$reload=300000;} // unter 4h idle 5 minuten intervall
    else {$reload=240000;} // fuer den rest 240 sekunden. da autikick auf 240 minuten steht duerfte dieser fall niemals auftreten
  }
}

?>

<script language="javascript">
<!--
function reload() {
document.location.href="<? print "$REQUEST_URI"; ?>";
}

immerreloaden=window.setInterval("reload()",<? print $reload; ?>);

function sendmsg(nick) {

  top.input.document.inputForm.text2.value="/msg "+nick+" ";

}

//-->
</script>

<?
//$db->close();
//$db2->close();
?>