<?
INCLUDE "./include/configuration.inc.php";
$header = new EasyTemplate("$basepath/templates/outputheader.tpl");
$header -> assign("TITLE",$title);
$header -> easy_print();



function Stream($chatuser,$chatroom)
{
	global $host,$database,$user,$password,$stoolonginactive;
	if($chatuser)
	{
		ignore_user_abort(1);
		$PingTime=1;
		$Ping=0;
		$query="SELECT id from chatmessages_$chatroom order by id desc limit 1";
		$query3="SELECT lastaction,away,ignorelist FROM chatusers where nick='$chatuser'";
		$db = new db_local;	
		$db2 = new db_local;

		// Aktueller Stand wird einmalig ausgelesen
		$db->query($query);
		$lastpos=$db->result();

		while(!connection_aborted())
		{

			// Autokick
			$db->query($query3);
			$db->next_record();
			$time = time();
			$onl = $time - $db->record[lastaction];
	    		$min = $onl/60;
			$min = sprintf("%.0lf",$min);
			$away = $db->record[away];
			$ignorelist = unserialize($db->record[ignorelist]);
	    		if($min>10)
	    		{
				#User has been very long inactive, so we check if he's away or not, so we can kick him ...	
				if($away=='0')
				{
			    		# User is not away, so lets kick him ...
			    		$db->query("UPDATE chatusers SET active='0' WHERE nick = '$nick'");
		    			echo $stoolonginactive;
		    			exit;
				}
				else if($min>30 && $away=='1')
				{
					# User is away, but has been inactive since 4 hours!
					# Too long, so say goodbye ;-)
					$db->query("UPDATE chatusers SET active='0' WHERE nick = '$chatuser'");
					echo $stoolonginactive;
					exit;
				}
			}
			// Ende Autokick
		

			// MSGs anzeigen
			// Aktuelle Position auslesen
			$db->query($query);
			$pos=$db->result();
			//print "alt: $lastpos neu: $pos<br>";
			// Mit alter Position vergleichen
			if($lastpos < $pos)
			{
				//print "neue msgs!<br>";
				$query2="SELECT message FROM chatmessages_$chatroom WHERE id > $lastpos"; 
				$db->query($query2);
				// Alle hinzugekommenen MSGs durchlaufen
				while ($db->next_record())
				{
					$text=stripslashes($db->record[message]);
					// Normale MSGs
					$schreiber = eregi("([0-9]{2}:[0-9]{2}:[0-9]{2}) (.*) &gt",$text,$regs);
					$schreiber = $regs[2];
					
					if(is_array($ignorelist) && in_array($schreiber,$ignorelist))
					{
					
					}
					else
					{
					
						if(!eregi("privatemessagestring",$text))
						{
							echo "$text";
						}
						// Private MSGs
						elseif(eregi("privatemessagestring $chatuser ",$text))
						{
							$text=eregi_replace("privatemessagestring $chatuser ","",$text);
							echo" $text";
						}
					}
					
				}
				
				$lastpos=$pos;		
			}
			else
			{
				//print "keine neuen msgs!<br>";
				echo " ";
			}
			// Neue Zeilen oder Leerzeichen an den Browser schicken
			flush();
	
			// Eine halbe Sekunde warten
			usleep(500000);
	    
		} // while connection

		$db->close();
	} //if user
} // Function




if (!isset($clear) || $clear!=1 || !eregi("sep_",$chatroom)) { // Zeigt die Meldungen nicht bei einem /clear-Befehl an

echo $welcomemsg;


// Gespeicherte Msgs anzeigen
$db = new db_local;
$db2 = new db_local;
$db->query("SELECT message,id FROM msgs where sentto='$chatuser' ORDER BY datum asc,uhrzeit asc");
$num = $db->num_rows();
if($num > 0) {
	print "$fontprefixa Es sind $num ungelesene Nachrichten f&uuml;r dich vorhanden:</font><br><br>";
	while ($db->next_record())
	{
		$message = $db->record[message];
		$id = $db->record[id];
		print $message;
		$db2->query("delete from msgs where id='$id'");
	}
}
//$db->close();
//$db2->close();


} // von clear

	$db = new db_local;
	$db->query("SELECT * FROM chatusers WHERE nick = '$chatuser'");
	$db->next_record();
	if ($db->record[pass] == $userpass)
	{

		Stream($chatuser,$chatroom);
	}
	else
	{
		echo "fehler";
	}
	
?>