<table align=center border=0 cellspacing=0 cellpadding=0>
<?
########################################
# This function was Posted by dividuum #
# on #php.de in IRCNet                 #
# Visit his homepage @                 #
# http://www.dividuum.de               #
########################################

for ($y=0;$y<16;$y++)
{
   echo  "<tr height=4>\n";

   for ($x=0;$x<16;$x++)
   {
      $abs00=sqrt(($x*$x)+($y*$y));
      if ($abs00>16)
         $abs00=16;
      
      $abs01=sqrt(($x*$x)+((16-$y)*(16-$y)));
      if ($abs01>16)
         $abs01=16;
      
      $abs10=sqrt(((16-$x)*(16-$x))+($y*$y));
      if ($abs10>16)
         $abs10=16;
    
      $red=((16-$abs00)*16)-1;
      if ($red<0)
         $red=0;
      
      $green=((16-$abs01)*16)-1;
      if ($green<0)
         $green=0;
      $blue= ((16-$abs10)*16)-1;
      if ($blue<0)
         $blue=0;
    
      $col = sprintf("%02x%02x%02x",$red,$green,$blue);
      echo  " <td width=4 bgcolor=\"#$col\"><a href=\"chatinput.php?chatuser=$chatuser&chatroom=$chatroom&userpass=$userpass&farbe=$col\" target=dummy><img src=images/blank.gif width=4 height=4 border=0 alt=\"$col\"></a></td>\n";
   }

   echo  "</tr>\n";
}    
?>
</table> 