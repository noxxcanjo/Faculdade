<?
INCLUDE "./include/configuration.inc.php";
if($chatroom != $oldroom)
{
$db = new db_local;
$db->query("SELECT name FROM chatrooms WHERE name = '$chatroom'");
$db->query("INSERT INTO chatmessages_$oldroom VALUES ('','$fontprefixb $suserchangedroom </font>','$chatuser','$date','','','')");
$db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$fontprefixa $sentered </font>','$chatuser','$date','','','')");
}
Header("Location:chatlogin.php?chatuser=$chatuser&chatroom=$chatroom&userpass=$userpass");
//$db->close();

?>