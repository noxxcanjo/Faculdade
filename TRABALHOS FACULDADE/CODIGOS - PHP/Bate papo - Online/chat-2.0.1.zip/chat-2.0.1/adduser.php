<?
INCLUDE "./include/configuration.inc.php";

$chatuser=strtolower($chatuser);
$chatuser=ereg_replace("[^a-zA-Z0-9]","_",$chatuser);

$db = new db_local;
$db -> query("SELECT count(*) FROM chatusers WHERE nick = '$chatuser'");
$num = $db->result();
if (!empty($useremail) && !empty($chatuser) && !empty($userpass) && !empty($realname) && $num == 0 && $userpass==$userpass)
{	# All entrys are correct..
	$header -> assign("BODY","");
	$header -> easy_print();
	$passwd = CRYPT ($userpass,"CRYPT_MD5");
	$created=date("Y-m-d");

	$db->query("INSERT INTO chatusers (nick,pass,room,name,email,creation) VALUES ('$chatuser','$passwd','','$realname','$useremail','$created')");
	echo "$fontprefix $sgoodreg <br><br><a href=\"index.php?chatuser=$chatuser\">$shome</a></font>";
	$footer -> easy_print();

}
else
{
    $errorstr = "<br><br>Bei deiner Registrierung ist was schief gelaufen:<br><br>";
    if (empty($chatuser))
    {
	$errorstr .= "&middot&nbsp;".$sbad_user."<br>";
    }
    if ($num > 0)
    {
	$errorstr .= "&middot&nbsp;".$suser_exists."<br>";
    }
    if (ereg("[^a-zA-Z0-9]",$chatuser)) {
      $errorstr.="&middot;&nbsp;Dein Benutzername enth&auml;lt nicht erlaubte Zeichen<br>";
    }
    if(empty($useremail))
    {
	$errorstr .= "&middot&nbsp;".$sbad_email."<br>";
    }
    if (empty($userpass))
    {
	$errorstr .= "&middot&nbsp;".$sbad_pass."<br>";
    }
    if (empty($realname))
    {
	$errorstr .= "&middot&nbsp;".$sbad_realname."<br>";
    }
    if($userpass != $userpass2)
    {
    	$errorstr .= "&middot&nbsp;".$spassnotsame."<br>";
    }

    
    $errorstr .="<br>Bitte korrigier den Fehler und registriere dich noch einmal:<br></font>";
    $errorstr = urlencode($errorstr);
    $chatuser = urlencode($chatuser);
    $useremail = urlencode($useremail);
    $realname = urlencode($realname);
    Header("Location: index.php?errorstr=$errorstr&cusername=$chatuser&cuseremail=$useremail&crealname=$realname");
    	
}	

$db->close();
?>