<?

INCLUDE "./include/configuration.inc.php";

$header -> assign("BODY","");
$header -> easy_print();
$tblheader -> assign("TBLTITLE",$sjumproom);
$tblheader -> assign("WIDTH","100%");
$tblheader -> assign("ALIGN","center");
$tblheader -> easy_print();

$db = new db_local;
$db -> query("SELECT name FROM chatrooms ORDER BY name");
while ($db->next_record())
{
    $room = $db->record[name];
    if(!eregi("sep_",$room))
    {
    	echo "<a href=\"chroom.php?chatuser=$chatuser&chatroom=$room&userpass=$userpass&oldroom=$chatroom\" target=\"_top\">$room</a> | ";
    }
}
$tblfooter -> easy_print();
$footer -> easy_print();
$db->close();
?>