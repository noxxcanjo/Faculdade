<?
INCLUDE "./include/configuration.inc.php";
$db = new db_local;
$db2 = new db_local;

$header -> assign("BODY","");
    
$header -> easy_print();
?>
<table border=0 width=100% cellspacing=0 cellpadding=10>
<tr>
    <td width=70% valign=top>
<?
$tblheader -> assign("TBLTITLE",$suser_login);
$tblheader -> assign("WIDTH","100%");
$tblheader -> assign("ALIGN","center");
$tblheader -> easy_print();

?>
<form method=POST action="chatlogin.php">
<table border=0 width=100% cellspacing=0 cellpadding=0>
<tr>
    <td align=right><? echo $susername ?>:</td>
    <td><input type=text name=chatuser></td>
</tr>
<tr>
    <td align=right><? echo $spassword ?>:</td>
    <td><input type=password name=userpassw></td>
</tr>
<tr>
    <td align=right><? echo $sroom ?>:</td>
    <td><select name=chatroom>
    <?
    $db->query("SELECT * FROM chatrooms ORDER BY name");

    while ($db->next_record())
    {
    	$room = $db->record[name];
    	if(!eregi("sep_",$room))
    	{
	    	$db2->query("SELECT count(*) FROM chatusers WHERE room = '$room' AND active= '1'");
    		$chatters = $db2->result();
    		echo  "<option value=\"$room\">$room ($chatters $schatter)"; 
    	}
    }
    ?>
    </select></td>
</tr>
<tr>
    <td colspan=2 align=center><input type=submit value="<? echo $slogin ?>"></td>
</tr>
</table>
</form>
<?
$tblfooter -> easy_print();
?>
<br>
<?
$tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");	
$tblheader -> assign("TBLTITLE",$snew_user);
$tblheader -> assign("WIDTH","100%");
$tblheader -> assign("ALIGN","center");
$tblheader -> easy_print();
echo $errorstr;
?>
<form method=POST action="adduser.php">
<table border=0 width=100% cellspacing=0 cellpadding=0>
<tr>
    <td align=right><? echo $susername ?>:</td>
    <td><input type=text name=chatuser value="<? echo $cusername; ?>" maxlength=20></td>
</tr>
<tr>
    <td align=right><? echo $spassword ?>:</td>
    <td><input type=password name=userpass maxlength=10></td>
</tr>
<tr>
    <td align=right><? echo $spassword ?>:</td>
    <td><input type=password name=userpass2 maxlength=10></td>
</tr>
<tr>
    <td align=right><? echo $srealname ?>:</td>
    <td><input type=text name=realname maxlength=50 value="<? echo $crealname ?>"></td>
</tr>
<tr>
    <td align=right><? echo $semail ?>:</td>
    <td><input type=text name=useremail maxlength=50 value="<? echo $cuseremail ?>"></td>
</tr>
<tr>
    <td colspan=2 align=center><input type=submit value="<? echo $screate_account; ?>"></td>
</tr>
</table>
</form>
<?
$tblfooter -> easy_print();
?>
	</td>
	<td width=30% valign=top>
<?
    $tblheader = new EasyTemplate("$basepath/templates/tblheader.tpl");
    $tblheader -> assign("WIDTH","100%");
    $tblheader -> assign("ALIGN","center");
    $tblheader -> assign("TBLTITLE",$sroomdescs);
    $tblheader -> easy_print();
    $db ->query("SELECT * FROM chatrooms ORDER BY name");
    $db2 = new db_local;
    while ($db->next_record())
    {
	$room = $db->record[name];
	
	if(!eregi("sep_",$room))
	{
		$db2->query("SELECT count(*) FROM chatusers WHERE active = '1' AND room = '$room'");
		$num =$db2->result();
		echo "<b>".$room." ($num $schatter $sinside)</b><br>".$db->record[descr]."<br><br>";
    }
   	}
    $tblfooter -> easy_print();
?>	
	</td>
</tr>
</table>
<?
$footer -> easy_print();
$db->close();
?>