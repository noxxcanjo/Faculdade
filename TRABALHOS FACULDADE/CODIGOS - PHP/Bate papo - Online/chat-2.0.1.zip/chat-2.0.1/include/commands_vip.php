<?
/* VIP Command File */
/* Only included if commands start with a + */

if(eregi("^\+v",$message))
{
	#Set Vip for user
	$message=eregi_replace("^\+v ","",$message);
	$db->query("SELECT * FROM chatusers WHERE nick='$message'");
	if($db->num_rows()>0)
	{
		$db->next_record();
		if($db->record[mode]!=2)
		{
			$db->query("UPDATE chatusers SET mode = '1' WHERE nick = '$message'");
			$msg = "privatemessagestring $chatuser $message $svip";
		}
		else
		{
			#User is Superuser, we don't want to downgrade him ...
			$msg = "privatemessagestring $chatuser $sdownerr";
		}
	}
}
else if (eregi("^\+n",$message))
{
	#Set normal user for a user
	$message = eregi_replace("^\+n ","",$message);
	$db->query("SELECT * FROM chatusers WHERE nick='$message'");
	if($db->num_rows()>0)
	{
		$db->next_record();
		if($db->record[mode]!=2)
		{
			$db->query("UPDATE chatusers SET mode ='0' WHERE nick = '$message'");
			$msg = "privatemessagestring $chatuser $message $snorm";
		}
		else
		{
			#User is Superuser, we don't want to downgrade him ...
			$msg = "privatemessagestring $chatuser $sdownerr";
		}
	}
}
else
{	
	#VIP Command not found
	$msg="privatemessagestring $chatuser $scommandnothere";
}
?>