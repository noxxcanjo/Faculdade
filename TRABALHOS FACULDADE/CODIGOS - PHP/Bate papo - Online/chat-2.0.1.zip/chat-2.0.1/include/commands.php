<?
/* General Commands reside in this file */

if (eregi("^/s ",$message))
{
	# Screaming
	$message = eregi_replace("^/s ","",$message);
	$message = strtoupper($message);
	$msg = "$msgprefix schreit: <b>".$message."</b>".$msgpostfix;
  $nodate=0;
}

//Vielen Dank an Oliver Kurlvink
//http://www.metal.de
else if (eregi("^/ficken$",$message) || eregi("^/poppen$",$message) || eregi("^/bumsen$",$message) || eregi("^/blasen$",$message) || eregi("^/sex$",$message))
{
	# Doing stuff
	$message = "-&gt; http://lie.be";
	$msg = "privatemessagestring $chatuser $msgprefix $message $msgpostfix";
  $nodate=1;
}

//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/help$",$message) || eregi("^/hilfe$",$message) || eregi("^/h$",$message))
{
	# Opens a help window

	print "
	<script language=\"Javascript\">
	<!--
	function openwin(url) {
	newwin=open(url,\"hilfe\",\"location-bar=no,menubar=no,status=no,scrollbars=yes,width=350,height=450\");
	}
	openwin('help/".$language."_index.html');
	//-->
	</script>
	";
	$message = "-&gt; Nachricht vom Chatbot: Die Hilfe &ouml;ffnet sich in einem separaten Fenster.";
	$msg = "privatemessagestring $chatuser $msgprefix $message $msgpostfix";
	$nodate=1;
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/info",$message))
{
	# Opens a new window with user information

	$message = eregi_replace("^/info ","",$message);
	$message = eregi_replace("^/info","",$message);
        $timestamp=time();

	print "
	<script language=\"Javascript\">
	<!--
	function openwin(url) {
	  newwin=open(url,\"x$timestamp\");
	}
	//-->
	</script>
	";

	if ($message!="") {
	  $db -> query("SELECT count(*) FROM chatusers WHERE nick = '$message'");
	  $num = $db->result();
	  if ($num!=0) {
	    print "
  	    <script language=\"Javascript\">
	    <!--
	    openwin('useroptions.php?suser=$chatuser&chatuser=$message');
	    //-->
	    </script>
	    ";
	    $message = "-&gt; Nachricht vom Chatbot: Ein neues Fenster mit Informationen zu $message wird ge&ouml;ffnet.";
  	  } else {
    	    $message = "-&gt; Nachricht vom Chatbot: Der Benutzer $message existiert nicht!";
	  }
	} else {
	  print "
	  <script language=\"Javascript\">
	  <!--
	  openwin('useroptions.php?suser=$chatuser&chatuser=$chatuser');
	  //-->
	  </script>
	  ";
	  $message = "-&gt; Nachricht vom Chatbot: Ein neues Fenster mit deinen Benutzerinformationen wird ge&ouml;ffnet.";
	}
	$msg = "privatemessagestring $chatuser $msgprefix $message $msgpostfix";
	$nodate=1;
}

//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

elseif (eregi("^/date",$message) || eregi("^/time",$message))
{
	# Display Date / Time
	$message = date("d.m.Y, H:i");
	$msg = "privatemessagestring $chatuser $msgprefix $message $msgpostfix";
  $nodate=1;
}


else if (eregi("^/col ",$message))
{
	# Color changing
	$color = eregi_replace("^/col ","",$message);
	$db->query("UPDATE chatusers SET col = '$color' WHERE nick = '$chatuser'");
  $msg="-&gt; Nachricht vom Chatbot: <font color=\"$color\">$chatuser hat die Farbe ge&auml;ndert</font>";
  $msg="$fontprefix $msgprefix $msg $msgpostfix </font>";
//   $db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$msg')");
//	$msg = "$chatuser $msgprefix $scolorchanged $msgpostfix";
  $nodate=1;
}
else if (eregi("^/me ",$message))
{
	# Sending emotions /me is alone -> user is alone
	$message = eregi_replace("^/me ","",$message);
	$msg = "".date('H:i:s')." $msgprefix <i>$chatuser $message</i> $msgpostfix";
  $nodate=1;
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/clear",$message))
{
	# Clears the screen
  print "
  <html>
  <head>
  <script language=\"Javascript\">
  <!--
  top.output.location.href=\"outputframe.php?chatuser=$chatuser&chatroom=$chatroom&userpass=$userpass&clear=1\";
  //-->
  </script>
  </head>
  <body>
  </body>
  </html>
";
}

else if (eregi("^/top",$message))
{
	# Displays top10 of most active chatters
	$db->query("SELECT nick, totaltime FROM chatusers ORDER BY totaltime DESC LIMIT 0,10");
	$msg .= "privatemessagestring $chatuser $msgprefix <br>$stop10<br><br>";
	while ($db->next_record())
	{
		$nick = $db->record[nick];
		$time = $db->record[totaltime] / 60;
		$time = sprintf("%.0lf",$time);
		$hours = sprintf("%.1lf",$time/60);
		if($chatuser == $db->record[nick])
		{
			$msg .="<b>".$db->record[nick].": $time Mins ($hours Stunden)</b><br>";
		}
		else
		{
			$msg .="<a href=\"useroptions.php?suser=$chatuser&chatuser=$nick\" target=_blank>".$db->record[nick]."</a>: $time Mins ($hours Stunden)<br>";

		}
	}
	$msg = eregi_replace("<br>$","",$msg);
	$msg .= "<br>$msgpostfix";
  $nodate=1;
}

else if (eregi("^/away",$message))
{
	# Mark the chatuser as away
	$db->query("UPDATE chatusers SET away = '1' WHERE nick = '$chatuser'");
	$db->query("INSERT INTO chatmessages_$chatroom VALUES('','$sisaway')");
	usleep(500000);
}
else if (eregi("^/j ",$message))
{
	# Jump into another room
	$message = eregi_replace("^/j ","",$message);
	$db->query("SELECT name FROM chatrooms WHERE name = '$message'");
	if($db->num_rows()>0)
	{
		$db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$fontprefix2 $suserchangedroom </font>','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
		Header("Location: chatlogin.php?chatuser=$chatuser&chatroom=$message&userpass=$userpass");
		exit;
	}
	else
	{
		$msg = "privatemessagestring $chatuser $sroomnotexists";
    $nodate=1;
	}
}
else if (eregi("^/ju ",$message))
{
	# Follow a user into a room
	$message=eregi_replace("^/ju ","",$message);
	$db->query("SELECT room FROM chatusers WHERE nick = '$message' AND active = '1'");
	if($db->num_rows()>0)
	{
		$db->next_record();
		$room = $db->record[room];
		if (!ereg("sep_",$room)) {
  		  $db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$suserchangedroom','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
		  Header("Location: chatlogin.php?chatuser=$chatuser&chatroom=$room&userpass=$userpass");
		  exit;
		} else {
		  $msg = "privatemessagestring $chatuser $fontprefix2 Nachricht vom Chatbot -&gt; Der User $message ist momentan in einem privaten Chatraum.</font><br>";
	          $nodate=1;
		}
	}
	else
	{
		$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; $susernotinchat </font><br>";
                $nodate=1;
	}
}
/* Out of date :) 
else if (eregi("^/msg ",$message))
{
	# For sending private messages
	$message = eregi_replace("^/msg ","",$message);
	$message = explode (" ",$message);
	$to = $message[0];
	$db->query("SELECT count(*) FROM chatusers WHERE nick = '$to' AND active = '1' AND room = '$chatroom'");
	if($db->result()>0)
	{
		$msg = implode (" ",$message);
		$msg = eregi_replace("^$to","",$msg);
		$msgto = "privatemessagestring $to $chatuser $sflisters $msgprefix $msg $msgpostfix";
		$db->query("INSERT INTO chatmessages_$chatroom VALUES ('','$msgto')");
		$msg = "privatemessagestring $chatuser @ $to: $msgprefix $msg $msgpostfix";
	}
	else
	{
		$msg = "privatemessagestring $chatuser $susernotinroom";
	}
	usleep(500000);
}
else if (eregi("^/tell ",$message))
{
	#For sending private messages to a user in another room
	$message = eregi_replace("^/tell ","",$message);
	$message = explode (" ",$message);
	$to = $message[0];
	$db->query("SELECT room FROM chatusers WHERE nick = '$to' AND active = '1'");
	if($db->num_rows()>0)
	{
		$db->next_record();
		$room = $db->record[room];
		$msg = implode (" ",$message);
		$msg = eregi_replace("^$to","",$msg);
		$msgto = "privatemessagestring $to $chatusers ($sroom: $chatroom) $sflisters $msgprefix $msg $msgpostfix";
		$db->query("INSERT INTO chatmessages_$romm VALUES ('','$msgto')");
		$msg = "privatemessagestring $chatuser @ $to: $msgprefix $msg $msgpostfix";
		usleep(500000);
	}
	else
	{
		$msg = "privatemessagestring $chatuser $susernotinchat";
	}
}
*/

//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/msg ",$message) || eregi("^/m ",$message))
{
	#For sending private messages to a user in any room
        if (eregi("^/msg ", $message)) {
  	  $message = eregi_replace("^/msg ","",$message);
        } else if (eregi("^/m ", $message)) {
  	  $message = eregi_replace("^/m ","",$message);
        }
	$message = explode (" ",$message);
	$to = strtolower($message[0]);

        //Gibt es den User?
        $db -> query("SELECT count(*) FROM chatusers WHERE nick = '$to'");
        $num = $db->result();
        if ( $num > 0) { // User existiert
		// Ist der User online? Wenn ja Raum rausfinden...
		$db->query("SELECT room FROM chatusers WHERE nick = '$to' AND active = '1'");
		if($db->num_rows()>0)
		{
			$db->next_record();
			$room = $db->record[room];
			$msg = implode (" ",$message);
			$msg = eregi_replace("^$to","",$msg);
	                $time=date("H:i:s");
			$msgto = "privatemessagestring $to $fontprefix <br>Nachricht von $chatuser um $time:<br> $msgprefix $msg $msgpostfix(Antworten: /msg $chatuser text)<br><br> </font>";
			$db->query("INSERT INTO chatmessages_$room VALUES ('','$msgto','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
			$msg = "privatemessagestring $chatuser <br>Deine Nachricht an $to wurde um $time versandt:<br>$msgprefix $msg $msgpostfix<br>";
	                $nodate=1;
			usleep(500000);
		}
		else // Wenn nicht, Msg zwischenspeichern...
		{
			$msg = implode (" ",$message);
			$msg = eregi_replace("^$to","",$msg);
	                $time=date("H:i:s");
	                $datege=date("d.m.Y");
	                $date=date("Y-m-d");
			$msgto = "$fontprefix Nachricht von $chatuser vom $datege um $time:<br> $msgprefix $msg $msgpostfix<br> </font>";
			$db->query("INSERT INTO msgs VALUES ('$date','$time','$chatuser','$to','$msgto','')");
			$msg = "privatemessagestring $chatuser <br>Deine Nachricht wurde gespeichert und $to angezeigt sobald er wieder in den Chat kommt:<br>$msgprefix $msg $msgpostfix<br>";
	                $nodate=1;
			usleep(500000);
		}
	} else { // Wenn der User nicht existiert...
		$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Der User $to existiert nicht!</font><br>";
		$nodate=1;
	}
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/quit",$message) || eregi("^/leave",$message) || eregi("^/logout",$message) || eregi("^/signoff",$message) || eregi("^/abort",$message) || eregi("^/bye",$message))
{
	# Logout
		Header("Location: logout.php?chatuser=$chatuser&userpass=$userpass&chatroom=$chatroom&killframes=1");
		exit;
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/isonline ",$message))
{
	#For checking if a user is online
        if (eregi("^/isonline ", $message)) {
  	  $message = eregi_replace("^/isonline ","",$message);
        }
	$message = explode (" ",$message);
	$usertocheck = strtolower($message[0]);

        //Gibt es den User?
        $db -> query("SELECT count(*) FROM chatusers WHERE nick = '$usertocheck'");
        $num = $db->result();
        if ( $num > 0) { // User existiert
		// Ist der User online? Wenn ja Raum rausfinden...
		$db->query("SELECT room FROM chatusers WHERE nick = '$usertocheck' AND active = '1'");
		if($db->num_rows()>0)
		{
			$db->next_record();
			$room = $db->record[room];
			if (ereg("sep_",$room)) {
				$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; $usertocheck befindet sich momentan in einem privaten Raum. Diesen Raum kannst du nicht betreten, aber du kannst $usertocheck eine MSG schicken!</font><br>";
			} else {
				$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; $usertocheck befindet sich momentan im Raum  <a href=\"chroom.php?chatuser=$chatuser&chatroom=$room$timestamp&userpass=$userpass&oldroom=$chatroom\" target=\"_top\" title=\"In den Raum wechseln\">$room</a>!</font><br>";
			}
	                $nodate=1;
			usleep(500000);
		}
		else // Wenn nicht online...
		{
			$db -> query("SELECT lastaction FROM chatusers WHERE nick = '$usertocheck'");
			$db -> next_record();
			$lastaction = date("d.m.Y H:i:s",$db->record[lastaction]);
			$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; $usertocheck war zuletzt online am $lastaction . Du kannst $usertocheck eine MSG schicken, die angezeigt wird, wenn er/sie das n&auml;hchste Mal im Chat ist!</font><br>";
	                $nodate=1;
			usleep(500000);
		}
	} else { // Wenn der User nicht existiert...
		$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Der User $usertocheck existiert nicht!</font><br>";
		$nodate=1;
	}
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/sep ",$message))
{
	#For chatting in private rooms
        if (eregi("^/sep ", $message)) {
  	  $message = eregi_replace("^/sep ","",$message);
        }
	$message = explode (" ",$message);
	$to = strtolower($message[0]); // Usernamen sind immer klein geschrieben
	$time=date("H:i:s");
	$datege=date("d.m.Y");

        //Gibt es den User?
        $db -> query("SELECT count(*) FROM chatusers WHERE nick = '$to'");
        $num = $db->result();
        if ( $num > 0) { // User existiert
		// Ist der User online? Wenn ja Raum rausfinden...
		$db->query("SELECT room,pass FROM chatusers WHERE nick = '$to' AND active = '1'");
		if($db->num_rows()>0)
		{
			$db->next_record();
			$room = $db->record[room];
			$topass = $db->record[pass];
			
			// Temporaeren Chatraum erzeugen
			$timestamp=mysql_result(mysql_query("select unix_timestamp()"),0,0);
			$query="CREATE TABLE chatmessages_sep_$chatuser$timestamp (
			   id int(10) NOT NULL auto_increment,
	   		   message longtext NOT NULL,
		           user char(250),
			   datum date NOT NULL,
			   ip char(15) NOT NULL,
			   xforwarded text NOT NULL,
			   hostname char(100) NOT NULL,
   			   PRIMARY KEY (id),
   			   KEY id (id),
   			   UNIQUE id_2 (id)
			)
			";
			$db2 = new db_local;
			$db2->query($query);
			$query="INSERT INTO chatrooms VALUES('sep_$chatuser$timestamp','Separee erzeugt von $chatuser f&uuml;r $to um $time am $datege','0','$timestamp')";
			$db2->query($query);

			$msgto = "privatemessagestring $to $fontprefix <br>$chatuser l&auml;dt dich in einen privaten Chatraum ein. Wenn du die Einladung annehmen willst  <a href=\"chroom.php?chatuser=$to&chatroom=sep_$chatuser$timestamp&userpass=$topass&oldroom=$room\" target=\"_top\" title=\"In den privaten Raum von $chatuser wechseln\">klick hier</a> ansonsten ignorier das Ganze :)...<br><br></font>";
			$db->query("INSERT INTO chatmessages_$room VALUES ('','$msgto','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
			$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Deine Einladung an $to wurde versandt. Du wirst gleich in deinen privaten Raum bef&ouml;rdert. <script language=\"javascript\">top.window.location.href=\"chroom.php?chatuser=$chatuser&chatroom=sep_$chatuser$timestamp&userpass=$userpass&oldroom=$chatroom\";</script></$msgpostfix<br>";
	                $nodate=1;
			usleep(500000);
		}
		else // oder nicht online?
		{
			$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; $to ist nicht online!</font><br>";
	                $nodate=1;
			usleep(500000);
		}
	} else { // Wenn der User nicht existiert...
		$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Der User $to existiert nicht!</font><br>";
		$nodate=1;
	}

}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if (eregi("^/invite ",$message))
{
	#Invite someone into a room
        if (eregi("^/invite ", $message)) {
  	  $message = eregi_replace("^/invite ","",$message);
        }
	$message = explode (" ",$message);
	$to = strtolower($message[0]); // Usernamen sind immer klein geschrieben
	$time=date("H:i:s");
	$datege=date("d.m.Y");

	//Ist der aktuelle Raum ein Separee?
	if (ereg("sep_",$chatroom)) {
	        //Gibt es den User?
        	$db -> query("SELECT count(*) FROM chatusers WHERE nick = '$to'");
        	$num = $db->result();
	        if ( $num > 0) { // User existiert
			// Ist der User online? Wenn ja Raum rausfinden...
			$db->query("SELECT room,pass FROM chatusers WHERE nick = '$to' AND active = '1'");
			if($db->num_rows()>0)
			{
				$db->next_record();
				$room = $db->record[room];
				$topass = $db->record[pass];

				$msgto = "privatemessagestring $to $fontprefix <br>$chatuser l&auml;dt dich in einen privaten Chatraum ein. Wenn du die Einladung annehmen willst  <a href=\"chroom.php?chatuser=$to&chatroom=$chatroom&userpass=$topass&oldroom=$room\" target=\"_top\" title=\"In den privaten Raum von $chatuser wechseln\">klick hier</a> ansonsten ignorier das Ganze :)...<br><br></font>";
				$db->query("INSERT INTO chatmessages_$room VALUES ('','$msgto','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
				$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Deine Einladung an $to wurde versandt.</font><br>";
		                $nodate=1;
				usleep(500000);
			}
			else // oder nicht online?
			{
				$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; $to ist nicht online!</font><br>";
		                $nodate=1;
				usleep(500000);
			}
		} else { // Wenn der User nicht existiert...
			$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Der User $to existiert nicht!</font><br>";
			$nodate=1;
		}
	} else { // wenn der aktuelle raum kein privater raum ist
		$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Der aktuelle Raum ist kein privater Raum!</font><br>";
		$nodate=1;
	}
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if(eregi("^/uptime$",$message) || eregi("^/load$",$message))
{
	$uptime=exec("uptime");
	$msg = "privatemessagestring $chatuser $uptime<br>";
        $nodate=1;
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if(eregi("^/usersonline$",$message))
{
	$db->query("SELECT count(*) FROM chatusers WHERE active = '1'");
	$user_online=$db->result();
	$msg = "privatemessagestring $chatuser $fontprefix Nachricht vom Chatbot -&gt; Es sind $user_online Chatter online!</font><br>";
        $nodate=1;
}
//Vielen Dank an Oliver Kurlvink
//http://www.metal.de

else if(eregi("^/stats$",$message))
{
	#Show some info
	$db->query("SELECT count(*) FROM chatrooms");
	$raeume_gesamt=$db->result();
	$db->query("SELECT count(*) FROM chatrooms where name like 'sep_%'");
	$seps_gesamt=$db->result();
	$db->query("SELECT count(*) FROM chatusers");
	$user_gesamt=$db->result();
	$db->query("SELECT count(*) FROM chatusers WHERE active = '1'");
	$user_online=$db->result();
	$db->query("SELECT count(*) FROM chatusers where banned!=0");
	$user_verbannt=$db->result();
	$db->query("SELECT sum(totaltime) FROM chatusers");
        $user_onlinezeit=sprintf("%.0lf",$db->result()/60/60);
        $user_middletime=sprintf("%.1lf",$user_onlinezeit/$user_gesamt);

	$db->query("SELECT nick, totaltime FROM chatusers ORDER BY totaltime DESC LIMIT 0,10");
	while ($db->next_record())
	{
		$time = $db->record[totaltime] / 60;
		$time = sprintf("%.1lf",$time/60);
		$top .=$db->record[nick]." ($time Stunden)<br>";
	}
        $zeit=time()-2419200;
	$db->query("SELECT count(*) FROM chatusers where lastaction>$zeit");
	$user_28tage=$db->result();
        $zeit=time()-1209600;
	$db->query("SELECT count(*) FROM chatusers where lastaction>$zeit");
	$user_14tage=$db->result();
        $zeit=time()-604800;
	$db->query("SELECT count(*) FROM chatusers where lastaction>$zeit");
	$user_7tage=$db->result();
        $zeit=time()-86400;
	$db->query("SELECT count(*) FROM chatusers where lastaction>$zeit");
	$user_gestern=$db->result();

	$uptime=exec("uptime");

	$msg = "privatemessagestring $chatuser <br>Statistiken:<br><br>
$uptime<br><br>
Chatr&auml;ume: $raeume_gesamt<br>
Davon private R&auml;ume: $seps_gesamt<br><br>

Registrierte Chatter: $user_gesamt<br>
Gesperrte Chatter: $user_verbannt<br>
in den letzten vier Wochen online: $user_28tage<br>
in den letzten zwei Wochen online: $user_14tage<br>
in der letzten Woche online: $user_7tage<br>
in den letzten 24h online: $user_gestern<br>
jetzt online: $user_online<br><br>

Gesamtonlinezeit: $user_onlinezeit Stunden<br>
Durchschnittliche Onlinezeit pro Chatter: $user_middletime Stunden<br><br>

Top-Chatter:<br>
$top
<br><br>
\n";

     $nodate=1;
}

else if(eregi("^/w$",$message))
{
	#To see, who's in the room
	$db->query("SELECT * FROM chatusers WHERE active = '1' AND room = '$chatroom' ORDER BY nick");
	while($db->next_record())
	{
		$nck = $db->record[nick];
		if ($nck == "$chatuser")
		{
			$users.="<b>$nck</b>, ";
		}
		else
		{
			$users.="$nck, ";
		}
		$msg = "privatemessagestring $chatuser".$sinside." ".$chatroom.":<br>\n".$users."<br>\n";
	}
}
else if(eregi("^/wc$",$message))
{
	#To see, who's in the chat
	$message=eregi_replace("^/wc$","",$message);
	$db2 = new db_local;
	$db -> query("SELECT * FROM chatrooms");
	$msg = "privatemessagestring $chatuser ";
	while ($db->next_record())
	{
		$room = $db->record[name];
		$db2->query("SELECT * FROM chatusers WHERE room='$room' AND active='1'");
		$num = $db2->num_rows();
		if($num > 0)
		{
			$msg.="$sinside $room:<br>\n";
			while($db2->next_record())
	  		{				
				$msg.=$db2->record[nick].", ";
			}
			$msg .= "<br>\n";
		}
		else
		{
			$msg .= "$sinside $room:<br>\n";
			$msg .= "privatemessagestring $chatuser $sroomisempty";
		}
		$msg.="<br>\n";
	}
}
else if(eregi("^/wc ",$message))
{
	#To see, who's in a specific room
	$message=eregi_replace("^/wc ","",$message);
	$db->query("SELECT count(*) FROM chatrooms WHERE name = '$message'");
	$num = $db->result();
	if($num>0)
	{
		$db->query("SELECT * FROM chatusers WHERE room='$message' AND active='1'");
		$msg = "privatemessagestring $chatuser $sinside $message: ".$db->num_rows()." $schatter<br>\n";
		while($db->next_record())
		{
			$msg.=$db->record[nick].", ";
		}
		$msg .= "<br>\n";
	}
	else
	{
		$msg ="privatemessagestring $chatuser $sroomnotexists";
	}
}
else if(eregi("/img=",$message)) /* 05-2000 by Ulrich S. Kapp, BIGPiNG! oHG */
{
	$subtext = @strstr($message,"/img=");
	if(strcspn($subtext," ") == strlen($subtext))
	{
		$dasBild = @substr($subtext,1);
	}
	else
	{
		$dasBild = @substr($subtext,1,((strcspn($subtext," ") - strlen($subtext))));
	}
	$bildURL = "<".eregi_replace("="," src=\"http://",$dasBild)."\">";
	$message = eregi_replace("/".$dasBild,$bildURL,$message);
	$message=addslashes($message);
	$msg="$chatuser: $msgprefix $message $msgpostfix";
}
else if (eregi("^/ignore ",$message))
{
	$iguser = eregi_replace("^/ignore ","",$message);
	if($chatuser == $iguser) 
	{
		$msg = "privatemessagestring $chatuser $msgprefix Du kannst dich nicht selber ignorieren!$msgpostfix";
	}
	else
	{
	$db->query("SELECT count(*) FROM chatusers WHERE nick = '$iguser'");
	
	if($db->result()>0)
	{
		$db -> query("SELECT ignorelist FROM chatusers WHERE nick = '$chatuser'");
		$db -> next_record();
		$ignorelist = unserialize($db->record[ignorelist]);
		if(!in_array($iguser,$ignorelist))
		{
			$ignorelist[] = $iguser;
		$ignorelist = serialize($ignorelist);
		$db -> query("UPDATE chatusers SET ignorelist = '$ignorelist' WHERE nick = '$chatuser'");
		$msg="privatemessagestring $chatuser $msgprefix User $iguser wure der Ignorelist hinzugef�gt $msgpostfix";
		}
		else
		{
			$msg = "privatemessagestring $chatuser $msgprefix User $iguser ist schon in der Ihnorelist! $msgpostfix";
		}
	}
	else
	{
		$msg = "privatemessagestring $chatuser $msgprefix Der User $iguser existiert nicht im Chat $msgpostfix";
	}
	}
}
else if (eregi("^/unignore ",$message))
{
	$iguser = eregi_replace("^/unignore ","",$message);
	$db->query("SELECT ignorelist FROM chatusers WHERE nick = '$chatuser'");
	$db->next_record();
	$ignorelist = unserialize($db->record[ignorelist]);
	if(in_array($iguser,$ignorelist))
	{
		for($i=0;$i<sizeof($ignorelist);$i++)
		{
			if($ignorelist[$i] == $iguser) array_splice($ignorelist,$i,1);
		}
		$ignorelist = serialize($ignorelist);
		$db -> query("UPDATE chatusers SET ignorelist = '$ignorelist' WHERE nick = '$chatuser'");
		$msg = "privatemessagestring $chatuser $msgprefix User $iguser ist aus deiner Ignorelist enternt worden $msgpostfix";
	}
	else
	{
		$msg= "privatemessagestring $chatuser $msgprefix User $iguser ist nicht in deiner Ignorelist! $msgpostfix";
	}
		
}
else if (eregi("^/ignore",$message))
{
	$db->query("SELECT ignorelist FROM chatusers WHERE nick = '$chatuser'");
	$db->next_record();
	$ignorelist = unserialize($db->record[ignorelist]);
	$msg = "privatemessagestring $chatuser $msgprefix Ignore-Liste:<br>";
	for($i=0;$i<sizeof($ignorelist);$i++)
	{
		$msg .="$ignorelist[$i]";
		if($i < (sizeof($ignorelist) -1)) $msg .=", ";
	}
	$msg .= $msgpostfix;
}
else
{
	$msg="privatemessagestring $chatuser $scommandnothere";
}
?>