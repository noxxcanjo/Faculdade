<?

/* Admin Command File */
/* Only included if commands start with an @ */
if (eregi("^\@del ",$message))
{
	# Permanently remove a chatuser
	$message=eregi_replace("^\@del ","",$message);
	$db->query("SELECT * FROM chatusers WHERE nick = '$message'");
	$db->next_record();
//	$room = $db->record[room];
	$msg = "$fontprefix2 -&gt; Nachricht vom Chatbot: $message wurde von $chatuser gel&ouml;scht.<br></font>";
//	$db->query("INSERT INTO chatmessages_$room VALUES('','$msg')");
	$db->query("DELETE FROM chatusers WHERE nick = '$message'");
	usleep(500000);
//	$msg = "privatemessagestring $chatuser $message $shasbeendeleted";
  $nodate=1;
}
else if(eregi("^@wc$",$message))
{
	#To see, who's in the chat
        $time = time();
	$message=eregi_replace("^@wc$","",$message);
	$db2 = new db_local;
        $db -> query("SELECT name FROM chatrooms where pos!=0 or name like '%sep_%' ORDER BY name");
	$msg = "privatemessagestring $chatuser <br>";
	while ($db->next_record())
	{
		$room = $db->record[name];
		$db2->query("SELECT * FROM chatusers WHERE room='$room' AND active='1'");
		$num = $db2->num_rows();
		if($num > 0)
		{
			$msg.="$sinside $room:<br>\n";
			while($db2->next_record())
	  		{				
                                $onl = $time - $db2->record[lastaction];
                                $min = $onl/60;
                                $min = number_format($min);
				$msg.=$db2->record[nick]." ($min), ";
			}
			$msg .= "<br>\n";
		}
		else
		{
			$msg .= "$sinside $room:<br>\n";
			$msg .= "privatemessagestring $chatuser $sroomisempty";
		}
		$msg.="<br>\n";
	}
  $nodate=1;
	$db2->close();
}
else if (eregi("^@broadcast ",$message) || eregi("^@b ",$message))
{
	$db2 = new db_local;
	# For sending a broadcast message to all users
        if (eregi("^@broadcast ", $message)) {
  	  $message = eregi_replace("^@broadcast ","",$message);
        } else if (eregi("^@b ", $message)) {
  	  $message = eregi_replace("^@b ","",$message);
        }
	$msg = "$fontprefix2 <br><font color=\"red\"><b>Systemmeldung:</b></font><br> $msgprefix $message $msgpostfix<br><br> </font>";
	$db->query("SELECT name FROM chatrooms");
	while($db->next_record())
	{
		$nextroom = $db->record[name];
		$db2->query("INSERT INTO chatmessages_$nextroom VALUES ('','$msg','$chatuser','$date','$usersip','$usersxforwarded','$usershostname')");
        	usleep(5000);
	}
	$db2->close();
        $msg = "privatemessagestring $chatuser $fontprefix2 -&gt; Nachricht vom Chatbot: Broadcast wurde verschickt.</font><br>";
        $nodate=1;
}
else if (eregi("^\@kick ",$message))
{
	# Kick a chatuser
	$message=eregi_replace("^\@kick ","",$message);
	$db->query("UPDATE chatusers SET active='0' WHERE nick = '$message'");
	$db->query("SELECT * FROM chatusers WHERE nick = '$message'");
	$db->next_record();
//	$room = $db->record[room];
	$msg = "$fontprefix2 -&gt; Nachricht vom Chatbot: $message ist von $chatuser aus dem Raum geschmissen worden.<br></font>";
//	$db->query("INSERT INTO chatmessages_$room VALUES('','$msg')");
	usleep(500000);
//	$msg = "privatemessagestring $chatuser $message $shasbeenkicked";
  $nodate=1;
}
else if (eregi("^\@ban ",$message))
{
	# Ban a chatuser
	$message=eregi_replace("^\@ban ","",$message);
	$db->query("UPDATE chatusers SET banned='1' WHERE nick = '$message'");
	$db->query("SELECT * FROM chatusers WHERE nick = '$message'");
	$db->next_record();
//	$room = $db->record[room];
	$msg = "$fontprefix2 -&gt; Nachricht vom Chatbot: $message wurde von $chatuser verbannt<br></font>";
//	$db->query("INSERT INTO chatmessages_$room VALUES('','$msg')");
	usleep(500000);
//	$msg = "privatemessagestring $chatuser $suserbanned";
  $nodate=1;
}
else if (eregi("^\@unban ",$message))
{
	# Unban a chatuser
	$message=eregi_replace("^\@unban ","",$message);
	$db->query("UPDATE chatusers SET banned='0' WHERE nick = '$message'");
	$db->query("SELECT * FROM chatusers WHERE nick = '$message'");
	$db->next_record();
//	$room = $db->record[room];
	$msg = "$fontprefix2 -&gt; Nachricht vom Chatbot: $message wurde von $chatuser entbannt und kann wieder chatten<br></font>";
//	$db->query("INSERT INTO chatmessages_$room VALUES('','$msg')");
	usleep(500000);
//	$msg = "privatemessagestring $chatuser $suserunbanned";
  $nodate=1;
}
else if(eregi("^\@op",$message))
{
	#Set Superuser for user
	$message=eregi_replace("^\@op ","",$message);
	$db->query("UPDATE chatusers SET mode = '2' WHERE nick = '$message'");
	$msg = "$fontprefix2 -&gt; Nachricht vom Chatbot: $message hat Superuser-Rechte erhalten<br></font>";
  $nodate=1;
}
else if(eregi("^\@deop",$message))
{
	#Set Superuser for user
	$message=eregi_replace("^\@deop ","",$message);
	$db->query("UPDATE chatusers SET mode = '0' WHERE nick = '$message'");
	$msg = "$fontprefix2 -&gt; Nachricht vom Chatbot: $message hat keine Sonderrechte mehr<br></font>";
  $nodate=1;
}
/*
else if(eregi("^\@img=",$message))
{
	$subtext = @strstr($message,"\@img=");
	if(strcspn($subtext," ") == strlen($subtext))
	{
		$dasBild = @substr($subtext,1);
	}
	else
	{
		$dasBild = @substr($subtext,1,((strcspn($subtext," ") - strlen($subtext))));
	}
	$bildURL = "<".eregi_replace("="," src=\"http://",$dasBild)."\">";
	$message = eregi_replace("/".$dasBild,$bildURL,$message);
	$message=addslashes($message);
	$msg="$msgprefix $message $msgpostfix";
  $nodate=0;
}
*/
else
{
	$msg="privatemessagestring $chatuser $scommandnothere";
  $nodate=1;
}
?>