<?
#########################################################################
#																		#
#			Configuration File for:										#
#																		#
#			Mazen's PHP Chat											#
#			by: Marcel Beerta ( beerta@weberweb.de )					#
#																		#
#########################################################################
#	Version: 2.0.1	 													#
#########################################################################
#																		#
# This Product is licensed under GPL!									#
# Anyone may copy, distribute it under these Terms!						#
# For private purpose only.												#
# Commercial customers have to pay 										#
#																		#
#########################################################################

#The Complete Server Path to the Chat
$basepath	= "/var/www/marceldev/chat-2.0.1";

#The URL to the Chat
$baseurl	= "http://mazen.mine.nu/marceldev/chat-2.0.1";

#The Title of the Chat
$title		= "Mazen's PHP Chat V2.0.1";

#What shall the users read, if they enter the Chatroom?
$welcomemsg	= "
		    Hallo $chatuser!<br><br>
		    Willkommen im Raum $chatroom.<br><br>
		";

#And What shall they read, if they leave ?
$logoutmsg	= "
		    Vielen Dank f&uuml;rs chatten!<br>
		    Komm doch bald mal wieder!
		";
#Specify a language file. They are stored in the lang dir
$language	= "german";

#Shall the Emotion-Icons be enabled?
#If not, also uncomment the lines in the language-specific help-file in the
#help dir
$emoticons = true;

#Which nick shall the Admin User have?
$adminuser="admin";

#And his Password?
$adminpass="secret";


#Default Foreground Color:
$deftextcol = "000000";

# Don't change these lines below! Only the Database settings below this block!
INCLUDE "$basepath/include/db_mysql.inc.php";
INCLUDE "$basepath/include/templates.inc.php"; 
INCLUDE "$basepath/lang/$language.lang.php";

# Please fill in the correct variables for Database Connection
class db_local extends db_sql
{
	#The Database host
	var $host = "localhost";
	
	#The User connecting to the DB
	var $user = "root";
	
	#The Password for the user
	var $password = "";
	
	#The Database Name
	var $database = "chat2";
}

# Please don't change these lines, too
$header = new EasyTemplate ("$basepath/templates/header.tpl");
$header -> assign("TITLE",$title);
$header -> assign("URL",$baseurl);
$footer = new EasyTemplate ("$basepath/templates/footer.tpl");
$tblheader = new EasyTemplate ("$basepath/templates/tblheader.tpl");
$tblfooter = new EasyTemplate ("$basepath/templates/tblfooter.tpl");   

?>