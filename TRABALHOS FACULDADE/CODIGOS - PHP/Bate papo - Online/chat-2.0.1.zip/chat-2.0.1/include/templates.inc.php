<?
class EasyTemplate
{
    var $error = "";                
    
    
    var $tags = array();            
    var $template_file = "";        
    
    function Easytemplate($template_file)
    {
        if(!file_exists($template_file))
        {
            $this->error = "The template file $template_file does not exist.";
        }
        
        $this->template_file = $template_file;
    }
    
    function assign($tag, $value)
    {
        if(empty($tag))
        {
            $this->error = "Tag name is empty";
            return(false);
        }
        
        $this->tags[$tag] = $value;
        
        return(true);
    }
        
    function easy_parse()
    {
        $contents = @implode("", (@file($this->template_file)));
        
        while(list($key, $value) = each($this->tags))
        {
            $tag = '{'.$key.'}';
            
            if(!strstr($contents, $tag))
            {
                $this->error = "Tag $tag not found in template ".$this->template_file.".";
                return(false);
            }
            
            $contents = str_replace($tag, $value, $contents);
        }
    
        return($contents);    
    }
    
    function easy_print()
    {
        $ret = $this->easy_parse();
        
        if($ret == false)
        {
            return(false);
        }
 
        print($ret);
        
        return(true);
    }
}

?>