<?
/* Here are all Smileys */
if(eregi(":)",$message))
{
	$message=eregi_replace(":)","<img src=\"$baseurl/images/smile.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":\(",$message))
{
	$message=eregi_replace(":\(","<img src=\"$baseurl/images/frown.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":o",$message))
{
	$message=eregi_replace(":o","<img src=\"$baseurl/images/redface.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(ereg(":D",$message))
{
	$message=eregi_replace(":D","<img src=\"$baseurl/images/biggrin.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":ent:",$message))
{
	$message=eregi_replace(":ent:","<img src=\"$baseurl/images/blue.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":shy:",$message))
{
	$message=eregi_replace(":shy:","<img src=\"$baseurl/images/shy.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":sleepy:",$message))
{
	$message=eregi_replace(":sleepy:","<img src=\"$baseurl/images/sleepy.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":sun:",$message))
{
	$message=eregi_replace(":sun:","<img src=\"$baseurl/images/sunglasses.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":lol:",$message))
{
	$message=eregi_replace(":lol:","<img src=\"$baseurl/images/lol.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":yawn:",$message))
{
	$message=eregi_replace(":yawn:","<img src=\"$baseurl/images/yawn.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":sg:",$message))
{
	$message=eregi_replace(":sg:","<img src=\"$baseurl/images/supergrin.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":embarass",$message))
{
	$message=eregi_replace(":embarass:","<img src=\"$baseurl/images/embarass.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":dead:",$message))
{
	$message=eregi_replace(":dead:","<img src=\"$baseurl/images/dead.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":cool:",$message))
{
	$message=eregi_replace(":cool:","<img src=\"$baseurl/images/cool.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":clown:",$message))
{
	$message=eregi_replace(":clown:","<img src=\"$baseurl/images/clown.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}

if(eregi(":pukey:",$message))
{
	$message=eregi_replace(":pukey:","<img src=\"$baseurl/images/pukey.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":eek:",$message))
{
	$message=eregi_replace(":eek:","<img src=\"$baseurl/images/eek.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":roll:",$message))
{
	$message=eregi_replace(":roll:","<img src=\"$baseurl/images/sarcblink.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":smoke:",$message))
{
	$message=eregi_replace(":smoke:","<img src=\"$baseurl/images/smokin.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":bounce:",$message))
{
	$message=eregi_replace(":bounce:","<img src=\"$baseurl/images/bounce.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":angry:",$message))
{
	$message=eregi_replace(":angry:","<img src=\"$baseurl/images/reallymad.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":confused:",$message))
{
	$message=eregi_replace(":confused:","<img src=\"$baseurl/images/confused.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":cry:",$message))
{
	$message=eregi_replace(":cry:","<img src=\"$baseurl/images/crying.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":devil:",$message))
{
	$message=eregi_replace(":devil:","<img src=\"$baseurl/images/devil.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":tongue:",$message))
{
	$message=eregi_replace(":tongue:","<img src=\"$baseurl/images/tongue.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":alien:",$message))
{
	$message=eregi_replace(":alien:","<img src=\"$baseurl/images/aysmile.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":tasty:",$message))
{
	$message=eregi_replace(":tasty:","<img src=\"$baseurl/images/tasty.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
if(eregi(":crazy:",$message))
{
	$message=eregi_replace(":crazy:","<img src=\"$baseurl/images/grazy.gif\">",$message);
	$msg = "$msgprefix $message $msgpostfix";
}
?>